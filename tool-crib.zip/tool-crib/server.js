// Tool Crib — check-out & return server
// Node.js + Express + SQLite. One process, one database file, no other services.
import express from "express";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "toolcrib.db");
const SECURE_COOKIE = process.env.SECURE_COOKIE === "true"; // set true when served over HTTPS
const SESSION_DAYS = 14;

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('keeper','tech')),
  passHash TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  createdAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  userId INTEGER NOT NULL,
  expiresAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tools (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT '',
  location TEXT NOT NULL DEFAULT '',
  calDue TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','out','service')),
  holderId INTEGER,
  holderName TEXT NOT NULL DEFAULT '',
  wo TEXT NOT NULL DEFAULT '',
  issuedAt INTEGER,
  dueAt TEXT NOT NULL DEFAULT '',
  createdAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL CHECK (type IN ('out','in')),
  toolId INTEGER NOT NULL,
  toolCode TEXT NOT NULL,
  toolName TEXT NOT NULL,
  techId INTEGER,
  techName TEXT NOT NULL DEFAULT '',
  wo TEXT NOT NULL DEFAULT '',
  dueAt TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL CHECK (status IN ('pending','done','declined','cancelled')),
  condition TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL DEFAULT '',
  createdAt INTEGER NOT NULL,
  handledAt INTEGER,
  handledBy INTEGER
);
CREATE INDEX IF NOT EXISTS idx_req_status ON requests(status);
CREATE INDEX IF NOT EXISTS idx_req_created ON requests(createdAt);
`);

// Columns added after the first release — added in place so existing databases keep their data.
const addCol = (table, col, def) => {
  if (!db.prepare(`PRAGMA table_info(${table})`).all().some(c => c.name === col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);
};
addCol("tools", "assetNo", "TEXT NOT NULL DEFAULT ''");   // number on the asset sticker
addCol("tools", "reqId", "INTEGER");                      // the check-out record for the current holder
addCol("tools", "ackAt", "INTEGER");                      // when the holder confirmed receipt
addCol("requests", "ackAt", "INTEGER");
addCol("requests", "ackAsset", "TEXT NOT NULL DEFAULT ''");
addCol("requests", "pledge", "TEXT NOT NULL DEFAULT ''"); // exact wording the technician accepted

/* ---------- passwords ---------- */
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(pw, salt, 64);
  return salt.toString("hex") + ":" + hash.toString("hex");
}
function checkPassword(pw, stored) {
  const [s, h] = String(stored).split(":");
  if (!s || !h) return false;
  const hash = crypto.scryptSync(pw, Buffer.from(s, "hex"), 64);
  const want = Buffer.from(h, "hex");
  return want.length === hash.length && crypto.timingSafeEqual(want, hash);
}

/* ---------- first keeper account ---------- */
if (!db.prepare("SELECT 1 FROM users WHERE role='keeper' LIMIT 1").get()) {
  const username = process.env.ADMIN_USERNAME || "keeper";
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString("base64url");
  db.prepare("INSERT INTO users (username,name,role,passHash,createdAt) VALUES (?,?,?,?,?)")
    .run(username, process.env.ADMIN_NAME || "Tool Room Keeper", "keeper", hashPassword(password), Date.now());
  console.log("\n================ FIRST LOGIN ================");
  console.log(`  Username: ${username}`);
  console.log(`  Password: ${process.env.ADMIN_PASSWORD ? "(the ADMIN_PASSWORD you set)" : password}`);
  console.log("  Change it after you sign in (Users tab).");
  console.log("=============================================\n");
}

/* ---------- helpers ---------- */
const now = () => Date.now();
const today = () => new Date().toLocaleDateString("en-CA", { timeZone: process.env.TZ || "Asia/Riyadh" });
const str = (v, max = 140) => String(v ?? "").trim().slice(0, max);
const isDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || ""));
const calExpired = t => !!t.calDue && t.calDue < today();
const normAsset = v => String(v || "").toUpperCase().replace(/[\s\-_./]/g, "");
// Same wording the technician sees on screen; stored with the record they confirm.
const pledgeText = (t, name, dueAt, asset) =>
  `I, ${name}, confirm that I have received tool ${t.code} (${t.name}), asset number ${asset}, ` +
  `and checked it against its asset sticker. I will return it to the tool room by ${dueAt || "the agreed date"}` +
  (t.calDue ? ` and before its calibration expires on ${t.calDue}` : "") +
  `. While this tool is in my custody I am responsible for it, including its loss, damage or misuse.`;
const dueCheck = (t, dueAt) => { if (t.calDue && dueAt > t.calDue) bad(`The return date can't be after the calibration due date (${t.calDue}).`); };
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = msg => { throw new HttpError(400, msg); };

function parseCookies(header) {
  const out = {};
  String(header || "").split(";").forEach(p => {
    const i = p.indexOf("=");
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function setSessionCookie(res, token, maxAgeSec) {
  res.setHeader("Set-Cookie",
    `tc_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${SECURE_COOKIE ? "; Secure" : ""}`);
}

/* ---------- app ---------- */
const app = express();
app.disable("x-powered-by");
app.set("trust proxy", true);
app.use(express.json({ limit: "1mb" }));
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "same-origin");
  next();
});

// Every write comes from our own page: require JSON (blocks simple cross-site form posts).
app.use("/api", (req, res, next) => {
  if (req.method !== "GET" && !req.is("application/json")) return res.status(415).json({ error: "JSON required" });
  next();
});

// Session lookup
app.use("/api", (req, res, next) => {
  const token = parseCookies(req.headers.cookie).tc_session;
  if (token) {
    const row = db.prepare(`SELECT u.id,u.username,u.name,u.role,u.active,s.expiresAt FROM sessions s
      JOIN users u ON u.id=s.userId WHERE s.token=?`).get(token);
    if (row && row.active && row.expiresAt > now()) { req.user = row; req.token = token; }
  }
  next();
});
const auth = (req, res, next) => req.user ? next() : res.status(401).json({ error: "Please sign in." });
const keeper = (req, res, next) => req.user?.role === "keeper" ? next() : res.status(403).json({ error: "Only the tool room keeper can do this." });
const tech = (req, res, next) => req.user?.role === "tech" ? next() : res.status(403).json({ error: "Only technicians can send requests." });

/* ---------- auth routes ---------- */
const attempts = new Map(); // ip -> {n, until}
app.post("/api/login", (req, res) => {
  const ip = req.ip, a = attempts.get(ip) || { n: 0, until: 0 };
  if (a.until > now()) return res.status(429).json({ error: "Too many attempts. Wait a few minutes and try again." });
  const u = db.prepare("SELECT * FROM users WHERE username=?").get(str(req.body.username, 60));
  if (!u || !u.active || !checkPassword(String(req.body.password || ""), u.passHash)) {
    a.n++; if (a.n >= 8) { a.until = now() + 5 * 60e3; a.n = 0; } attempts.set(ip, a);
    return res.status(401).json({ error: "Wrong username or password." });
  }
  attempts.delete(ip);
  const token = crypto.randomBytes(32).toString("hex");
  db.prepare("DELETE FROM sessions WHERE expiresAt < ?").run(now());
  db.prepare("INSERT INTO sessions (token,userId,expiresAt) VALUES (?,?,?)").run(token, u.id, now() + SESSION_DAYS * 864e5);
  setSessionCookie(res, token, SESSION_DAYS * 86400);
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => {
  if (req.token) db.prepare("DELETE FROM sessions WHERE token=?").run(req.token);
  setSessionCookie(res, "", 0);
  res.json({ ok: true });
});
app.post("/api/me/password", auth, (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (!checkPassword(String(req.body.current || ""), u.passHash)) bad("Your current password is wrong.");
  const pw = String(req.body.password || "");
  if (pw.length < 8) bad("Use at least 8 characters.");
  db.prepare("UPDATE users SET passHash=? WHERE id=?").run(hashPassword(pw), u.id);
  db.prepare("DELETE FROM sessions WHERE userId=? AND token<>?").run(u.id, req.token);
  res.json({ ok: true });
});

/* ---------- state ---------- */
app.get("/api/state", auth, (req, res) => {
  // Technicians never receive asset numbers: they must read them off the sticker to confirm receipt.
  const tools = db.prepare("SELECT * FROM tools ORDER BY code").all()
    .map(t => req.user.role === "keeper" ? t : (({ assetNo, ...rest }) => rest)(t));
  const requests = req.user.role === "keeper"
    ? db.prepare("SELECT * FROM requests ORDER BY createdAt DESC LIMIT 800").all()
    : db.prepare("SELECT * FROM requests WHERE techId=? OR status='pending' ORDER BY createdAt DESC LIMIT 800").all(req.user.id)
        .map(r => r.techId === req.user.id ? r : { id: r.id, type: r.type, toolId: r.toolId, status: r.status, techId: null, createdAt: r.createdAt });
  const people = {};
  db.prepare("SELECT id,name FROM users").all().forEach(p => { people[p.id] = p.name; });
  const technicians = req.user.role === "keeper"
    ? db.prepare("SELECT id,name,username FROM users WHERE role='tech' AND active=1 ORDER BY name").all() : [];
  res.json({ me: { id: req.user.id, name: req.user.name, username: req.user.username, role: req.user.role },
    today: today(), tools, requests, people, technicians });
});

/* ---------- technician ---------- */
app.post("/api/requests", auth, tech, (req, res) => {
  const type = req.body.type === "in" ? "in" : "out";
  const tool = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(req.body.toolId));
  if (!tool) bad("This tool is no longer in the inventory.");
  if (type === "out") {
    const wo = str(req.body.wo, 40), dueAt = str(req.body.dueAt, 10);
    if (!wo) bad("Enter the work order number.");
    if (!isDate(dueAt) || dueAt < today()) bad("Pick a return date from today onwards.");
    if (tool.status !== "available") bad("This tool isn't available right now.");
    if (calExpired(tool)) bad("This tool's calibration has expired.");
    dueCheck(tool, dueAt);
    if (db.prepare("SELECT 1 FROM requests WHERE toolId=? AND type='out' AND status='pending'").get(tool.id)) bad("Someone already requested this tool.");
    db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,dueAt,note,status,createdAt)
      VALUES ('out',?,?,?,?,?,?,?,?,'pending',?)`).run(tool.id, tool.code, tool.name, req.user.id, req.user.name, wo, dueAt, str(req.body.note), now());
  } else {
    if (tool.status !== "out" || tool.holderId !== req.user.id) bad("This tool isn't checked out to you.");
    if (db.prepare("SELECT 1 FROM requests WHERE toolId=? AND type='in' AND status='pending'").get(tool.id)) bad("A return is already pending for this tool.");
    db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,note,status,createdAt)
      VALUES ('in',?,?,?,?,?,?,?,'pending',?)`).run(tool.id, tool.code, tool.name, req.user.id, req.user.name, tool.wo, str(req.body.note), now());
  }
  res.json({ ok: true });
});
app.post("/api/requests/:id/cancel", auth, (req, res) => {
  const r = db.prepare("SELECT * FROM requests WHERE id=?").get(Number(req.params.id));
  if (!r || r.status !== "pending") bad("This request is no longer pending.");
  if (req.user.role !== "keeper" && r.techId !== req.user.id) bad("You can only cancel your own requests.");
  db.prepare("UPDATE requests SET status='cancelled', handledAt=?, handledBy=? WHERE id=?").run(now(), req.user.id, r.id);
  res.json({ ok: true });
});

// Technician confirms receipt: asset number from the sticker + responsibility pledge.
const ackTries = new Map(); // "user:tool" -> {n, until}
app.post("/api/tools/:id/ack", auth, tech, (req, res) => {
  const t = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(req.params.id));
  if (!t || t.status !== "out" || t.holderId !== req.user.id) bad("This tool isn't checked out to you.");
  if (t.ackAt) bad("You've already confirmed this tool.");
  if (req.body.agree !== true) bad("Tick the box to accept responsibility for the tool.");
  const key = req.user.id + ":" + t.id, a = ackTries.get(key) || { n: 0, until: 0 };
  if (a.until > now()) bad("Too many wrong asset numbers. Ask the tool room keeper to check the sticker with you.");
  const typed = str(req.body.assetNo, 40);
  if (!typed) bad("Type the asset number from the sticker on the tool.");
  if (normAsset(typed) !== normAsset(t.assetNo || t.code)) {
    a.n++; if (a.n >= 5) { a.until = now() + 10 * 60e3; a.n = 0; } ackTries.set(key, a);
    bad("That asset number doesn't match this tool. Check the sticker and try again. If it's a different tool, return it to the keeper.");
  }
  ackTries.delete(key);
  const ts = now(), pledge = pledgeText(t, req.user.name, t.dueAt, typed);
  db.transaction(() => {
    db.prepare("UPDATE tools SET ackAt=? WHERE id=?").run(ts, t.id);
    if (t.reqId) db.prepare("UPDATE requests SET ackAt=?, ackAsset=?, pledge=? WHERE id=?").run(ts, typed, pledge, t.reqId);
  })();
  res.json({ ok: true });
});

/* ---------- keeper: requests ---------- */
app.post("/api/requests/:id/issue", auth, keeper, (req, res) => {
  db.transaction(() => {
    const r = db.prepare("SELECT * FROM requests WHERE id=?").get(Number(req.params.id));
    if (!r || r.status !== "pending" || r.type !== "out") bad("This request is no longer pending.");
    const t = db.prepare("SELECT * FROM tools WHERE id=?").get(r.toolId);
    if (!t) bad("This tool is no longer in the inventory.");
    if (t.status !== "available") bad("This tool isn't available right now.");
    if (calExpired(t)) bad("Calibration expired. Recalibrate before issuing.");
    dueCheck(t, r.dueAt || today());
    const ts = now();
    db.prepare("UPDATE tools SET status='out', holderId=?, holderName=?, wo=?, issuedAt=?, dueAt=?, reqId=?, ackAt=NULL WHERE id=?")
      .run(r.techId, r.techName, r.wo, ts, r.dueAt || today(), r.id, t.id);
    db.prepare("UPDATE requests SET status='done', handledAt=?, handledBy=? WHERE id=?").run(ts, req.user.id, r.id);
  })();
  res.json({ ok: true });
});
app.post("/api/requests/:id/decline", auth, keeper, (req, res) => {
  const reason = str(req.body.reason);
  if (!reason) bad("Give the technician a reason.");
  const r = db.prepare("SELECT * FROM requests WHERE id=?").get(Number(req.params.id));
  if (!r || r.status !== "pending") bad("This request is no longer pending.");
  db.prepare("UPDATE requests SET status='declined', reason=?, handledAt=?, handledBy=? WHERE id=?").run(reason, now(), req.user.id, r.id);
  res.json({ ok: true });
});

/* ---------- keeper: tools ---------- */
app.post("/api/tools/:id/issue", auth, keeper, (req, res) => {
  db.transaction(() => {
    const t = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(req.params.id));
    if (!t) bad("This tool is no longer in the inventory.");
    if (t.status !== "available") bad("This tool isn't available right now.");
    if (calExpired(t)) bad("Calibration expired. Recalibrate before issuing.");
    const wo = str(req.body.wo, 40), dueAt = str(req.body.dueAt, 10);
    if (!wo) bad("Enter the work order number.");
    if (!isDate(dueAt)) bad("Pick a return date.");
    let techId = null, techName = str(req.body.name, 80);
    if (req.body.techId) {
      const u = db.prepare("SELECT * FROM users WHERE id=? AND role='tech' AND active=1").get(Number(req.body.techId));
      if (!u) bad("Pick a technician from the list.");
      techId = u.id; techName = u.name;
    }
    if (!techName) bad("Choose the technician or type their name.");
    dueCheck(t, dueAt);
    const ts = now();
    const ins = db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,dueAt,note,status,createdAt,handledAt,handledBy)
      VALUES ('out',?,?,?,?,?,?,?,?,'done',?,?,?)`).run(t.id, t.code, t.name, techId, techName, wo, dueAt,
      techId ? "Issued at counter" : "Issued at counter — no account, paper sign-off", ts, ts, req.user.id);
    db.prepare("UPDATE tools SET status='out', holderId=?, holderName=?, wo=?, issuedAt=?, dueAt=?, reqId=?, ackAt=NULL WHERE id=?")
      .run(techId, techName, wo, ts, dueAt, ins.lastInsertRowid, t.id);
  })();
  res.json({ ok: true });
});
app.post("/api/tools/:id/receive", auth, keeper, (req, res) => {
  db.transaction(() => {
    const t = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(req.params.id));
    if (!t || t.status !== "out") bad("This tool isn't checked out.");
    const cond = req.body.condition === "damaged" ? "damaged" : "good", remark = str(req.body.remark), ts = now();
    db.prepare("UPDATE tools SET status=?, holderId=NULL, holderName='', wo='', issuedAt=NULL, dueAt='', reqId=NULL, ackAt=NULL WHERE id=?")
      .run(cond === "damaged" ? "service" : "available", t.id);
    const open = db.prepare("SELECT id FROM requests WHERE toolId=? AND type='in' AND status='pending'").get(t.id);
    if (open) db.prepare("UPDATE requests SET status='done', condition=?, reason=?, handledAt=?, handledBy=? WHERE id=?").run(cond, remark, ts, req.user.id, open.id);
    else db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,status,condition,reason,createdAt,handledAt,handledBy)
      VALUES ('in',?,?,?,?,?,?,'done',?,?,?,?,?)`).run(t.id, t.code, t.name, t.holderId, t.holderName, t.wo, cond, remark, ts, ts, req.user.id);
  })();
  res.json({ ok: true });
});

function toolFields(b) {
  const f = { code: str(b.code, 30), name: str(b.name, 80), category: str(b.category, 40), location: str(b.location, 40), calDue: isDate(b.calDue) ? b.calDue : "", assetNo: str(b.assetNo, 40) };
  if (!f.code) bad("Enter a tool code.");
  if (!f.name) bad("Enter the tool name.");
  return f;
}
app.post("/api/tools", auth, keeper, (req, res) => {
  const f = toolFields(req.body);
  if (db.prepare("SELECT 1 FROM tools WHERE code=?").get(f.code)) bad(`A tool with code ${f.code} already exists.`);
  db.prepare("INSERT INTO tools (code,name,category,location,calDue,assetNo,createdAt) VALUES (?,?,?,?,?,?,?)").run(f.code, f.name, f.category, f.location, f.calDue, f.assetNo, now());
  res.json({ ok: true });
});
app.put("/api/tools/:id", auth, keeper, (req, res) => {
  const t = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(req.params.id));
  if (!t) bad("This tool is no longer in the inventory.");
  const f = toolFields({ ...req.body, code: t.code });
  let status = t.status;
  if (t.status !== "out" && ["available", "service"].includes(req.body.status)) status = req.body.status;
  db.prepare("UPDATE tools SET name=?, category=?, location=?, calDue=?, assetNo=?, status=? WHERE id=?").run(f.name, f.category, f.location, f.calDue, f.assetNo, status, t.id);
  res.json({ ok: true });
});
app.delete("/api/tools/:id", auth, keeper, (req, res) => {
  const t = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(req.params.id));
  if (!t) return res.json({ ok: true });
  if (t.status === "out") bad("Receive this tool before removing it.");
  db.prepare("UPDATE requests SET status='cancelled', handledAt=?, handledBy=? WHERE toolId=? AND status='pending'").run(now(), req.user.id, t.id);
  db.prepare("DELETE FROM tools WHERE id=?").run(t.id);
  res.json({ ok: true });
});
app.post("/api/tools/bulk", auth, keeper, (req, res) => {
  const lines = String(req.body.rows || "").split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  let added = 0, updated = 0, skipped = 0;
  const find = db.prepare("SELECT id FROM tools WHERE code=?");
  const ins = db.prepare("INSERT INTO tools (code,name,category,location,calDue,assetNo,createdAt) VALUES (?,?,?,?,?,?,?)");
  const upd = db.prepare("UPDATE tools SET name=?, category=?, location=?, calDue=?, assetNo=? WHERE id=?");
  db.transaction(() => {
    for (const l of lines) {
      const [code, name, category = "", location = "", calDue = "", assetNo = ""] = l.split(/\t|,/).map(s => s.trim());
      if (!code || !name || /^code$/i.test(code)) { skipped++; continue; }
      const f = { code: str(code, 30), name: str(name, 80), category: str(category, 40), location: str(location, 40), calDue: isDate(calDue) ? calDue : "", assetNo: str(assetNo, 40) };
      const ex = find.get(f.code);
      if (ex) { upd.run(f.name, f.category, f.location, f.calDue, f.assetNo, ex.id); updated++; }
      else { ins.run(f.code, f.name, f.category, f.location, f.calDue, f.assetNo, now()); added++; }
    }
  })();
  res.json({ ok: true, added, updated, skipped });
});

/* ---------- keeper: users ---------- */
app.get("/api/users", auth, keeper, (req, res) => {
  res.json(db.prepare("SELECT id,username,name,role,active,createdAt FROM users ORDER BY role, name").all());
});
app.post("/api/users", auth, keeper, (req, res) => {
  const username = str(req.body.username, 40), name = str(req.body.name, 80), role = req.body.role === "keeper" ? "keeper" : "tech";
  const pw = String(req.body.password || "");
  if (!/^[A-Za-z0-9._-]{3,40}$/.test(username)) bad("Username: 3–40 letters, numbers, dots, dashes or underscores.");
  if (!name) bad("Enter the person's name.");
  if (pw.length < 8) bad("Password must be at least 8 characters.");
  if (db.prepare("SELECT 1 FROM users WHERE username=?").get(username)) bad("That username is taken.");
  db.prepare("INSERT INTO users (username,name,role,passHash,createdAt) VALUES (?,?,?,?,?)").run(username, name, role, hashPassword(pw), now());
  res.json({ ok: true });
});
app.put("/api/users/:id", auth, keeper, (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(Number(req.params.id));
  if (!u) bad("User not found.");
  const name = str(req.body.name, 80) || u.name;
  const active = req.body.active === undefined ? u.active : (req.body.active ? 1 : 0);
  if (u.id === req.user.id && !active) bad("You can't deactivate your own account.");
  db.prepare("UPDATE users SET name=?, active=? WHERE id=?").run(name, active, u.id);
  if (req.body.password) {
    if (String(req.body.password).length < 8) bad("Password must be at least 8 characters.");
    db.prepare("UPDATE users SET passHash=? WHERE id=?").run(hashPassword(String(req.body.password)), u.id);
    db.prepare("DELETE FROM sessions WHERE userId=?").run(u.id);
  }
  if (!active) db.prepare("DELETE FROM sessions WHERE userId=?").run(u.id);
  res.json({ ok: true });
});

/* ---------- keeper: export ---------- */
app.get("/api/export/log.csv", auth, keeper, (req, res) => {
  const people = {}; db.prepare("SELECT id,name FROM users").all().forEach(p => people[p.id] = p.name);
  const rows = db.prepare("SELECT * FROM requests ORDER BY createdAt").all();
  const iso = ms => ms ? new Date(ms).toISOString().replace("T", " ").slice(0, 16) : "";
  const q = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const head = ["Request ID","Type","Tool code","Tool name","Technician","Work order","Return by","Note","Status","Condition","Remark / reason","Requested (UTC)","Handled (UTC)","Handled by","Receipt confirmed (UTC)","Asset no. typed by technician","Pledge accepted"];
  const body = rows.map(r => [r.id, r.type === "out" ? "Check-out" : "Return", r.toolCode, r.toolName, r.techName || people[r.techId] || "", r.wo, r.dueAt, r.note,
    r.status, r.condition, r.reason, iso(r.createdAt), iso(r.handledAt), people[r.handledBy] || "", iso(r.ackAt), r.ackAsset, r.pledge].map(q).join(","));
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="tool-crib-log-${today()}.csv"`);
  res.send("﻿" + [head.map(q).join(","), ...body].join("\r\n"));
});

/* ---------- static + errors ---------- */
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server. Try again." });
});

app.listen(PORT, () => console.log(`Tool Crib running on http://localhost:${PORT}`));
