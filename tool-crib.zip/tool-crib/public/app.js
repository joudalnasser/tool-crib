// Tool Crib — browser app. Talks to the server through relative "api/..." URLs,
// so the site also works when hosted under a sub-path.
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtT = ms => ms ? new Date(ms).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "—";
const fmtD = d => d ? new Date(d + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";

let me = null, tools = [], reqs = [], people = {}, technicians = [], users = [], serverToday = "";
let tab = { keeper: "queue", tech: "tools" }, q = "", cat = "All", pollTimer = null;
const today = () => serverToday || new Date().toLocaleDateString("en-CA");
const addDays = (d, n) => { const x = new Date(d + "T00:00:00"); x.setDate(x.getDate() + n); return x.toLocaleDateString("en-CA"); };
const role = () => me?.role === "keeper" ? "keeper" : "tech";

/* ---------- network ---------- */
async function api(path, body, method) {
  const res = await fetch("api/" + path, {
    method: method || (body ? "POST" : "GET"),
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
    credentials: "same-origin",
  });
  if (res.status === 401 && path !== "login") { showLogin(); throw new Error("Please sign in."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Couldn't reach the server. Check your connection.");
  return data;
}
function toast(msg) { const t = $("#toast"); (($("#dlg").open && $("#dlg")) || document.body).append(t); t.textContent = msg; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => t.hidden = true, 3500); }
async function act(fn, okMsg) {
  try { const r = await fn(); await load(); if (okMsg) toast(typeof okMsg === "function" ? okMsg(r) : okMsg); return true; }
  catch (e) { toast(e.message); return false; }
}
async function load() {
  const s = await api("state");
  me = s.me; tools = s.tools; reqs = s.requests; people = s.people; technicians = s.technicians; serverToday = s.today;
  if (me.role === "keeper" && tab.keeper === "users") users = await api("users");
  draw();
}

/* ---------- login ---------- */
function showLogin() {
  clearInterval(pollTimer); pollTimer = null; me = null;
  $("#appView").hidden = true; $("#loginView").hidden = false; $("#lu").focus();
}
$("#loginForm").addEventListener("submit", async ev => {
  ev.preventDefault(); $("#loginErr").textContent = "";
  try {
    await api("login", { username: $("#lu").value, password: $("#lp").value });
    $("#lp").value = ""; await start();
  } catch (e) { $("#loginErr").textContent = e.message; }
});
async function start() {
  await load();
  $("#loginView").hidden = true; $("#appView").hidden = false;
  clearInterval(pollTimer);
  pollTimer = setInterval(() => { if (!document.hidden && !$("#dlg").open) load().catch(() => {}); }, 8000);
}
document.addEventListener("visibilitychange", () => { if (!document.hidden && me) load().catch(() => {}); });

/* ---------- derived ---------- */
const person = (id, fallback) => (id && people[id]) || fallback || "Walk-up";
const calState = t => { if (!t.calDue) return null; const d = today(); if (t.calDue < d) return "expired"; if (t.calDue <= addDays(d, 14)) return "soon"; return "ok"; };
const isOverdue = t => t.status === "out" && t.dueAt && t.dueAt < today();
const pending = () => reqs.filter(r => r.status === "pending");
const myPending = (toolId, type) => reqs.find(r => r.status === "pending" && r.toolId === toolId && r.techId === me.id && (!type || r.type === type));
const anyPendingOut = toolId => reqs.find(r => r.status === "pending" && r.toolId === toolId && r.type === "out");
const toolById = id => tools.find(t => t.id === Number(id));
const unconfirmed = () => tools.filter(t => t.status === "out" && t.holderId === me.id && !t.ackAt);
const ackPill = t => t.ackAt ? `<span class="pill ok">Receipt confirmed ${esc(fmtT(t.ackAt))}</span>`
  : (t.holderId ? `<span class="pill warn">${role() === "keeper" ? "Awaiting technician confirmation" : "Not confirmed yet"}</span>` : `<span class="pill mute">No account · paper sign-off</span>`);
const pledgeHtml = (t, asset) => `I, <b>${esc(me.name)}</b>, confirm that I have received tool <b>${esc(t.code)}</b> (${esc(t.name)}), asset number <b>${asset ? esc(asset) : "[the number you type above]"}</b>, and checked it against its asset sticker. I will return it to the tool room by <b>${esc(t.dueAt || "the agreed date")}</b>${t.calDue ? ` and before its calibration expires on <b>${esc(t.calDue)}</b>` : ""}. While this tool is in my custody I am responsible for it, including its loss, damage or misuse.`;

function statusPills(t) {
  const p = [];
  if (t.status === "out") p.push(isOverdue(t) ? `<span class="pill bad">Overdue</span>` : `<span class="pill info">Checked out</span>`);
  else if (t.status === "service") p.push(`<span class="pill mute">Out of service</span>`);
  else p.push(`<span class="pill ok">Available</span>`);
  const c = calState(t);
  if (c === "expired") p.push(`<span class="pill bad">Cal expired ${esc(fmtD(t.calDue))}</span>`);
  else if (c === "soon") p.push(`<span class="pill warn">Cal due ${esc(fmtD(t.calDue))}</span>`);
  return `<div class="pills">${p.join("")}</div>`;
}
const tagHtml = t => `<span class="tag">${esc(t.code || t.toolCode || "—")}</span>`;

/* ---------- header ---------- */
function drawHeader() {
  const v = role();
  $("#meName").textContent = me.name;
  $("#meRole").textContent = v === "keeper" ? "Tool room keeper" : "Technician";
  $("#roleLine").textContent = v === "keeper" ? "Keeper desk · issue & receive" : "Technician · request & return";
  const mine = tools.filter(t => t.status === "out" && t.holderId === me.id).length;
  const unconf = unconfirmed().length;
  const tabs = v === "keeper"
    ? [["queue", "Requests", pending().length, true], ["out", "Checked out", tools.filter(t => t.status === "out").length], ["inventory", "Inventory", tools.length], ["log", "Log"], ["users", "Users"]]
    : [["tools", "Tools"], ["mine", unconf ? "My tools · confirm" : "My tools", mine, unconf > 0], ["requests", "My requests", reqs.filter(r => r.techId === me.id && r.status === "pending").length]];
  $("#tabs").innerHTML = tabs.map(([k, l, n, hot]) =>
    `<button type="button" data-tab="${k}" aria-current="${tab[v] === k}">${l}${n != null ? `<span class="count${hot && n ? " hot" : ""}">${n}</span>` : ""}</button>`).join("");
}

/* ---------- technician views ---------- */
function vToolsTech() {
  const cats = ["All", ...[...new Set(tools.map(t => t.category).filter(Boolean))].sort()];
  const list = tools.filter(t => (cat === "All" || t.category === cat) &&
    (!q || `${t.code} ${t.name} ${t.category} ${t.location}`.toLowerCase().includes(q.toLowerCase())))
    .sort((a, b) => (a.status === "available" ? 0 : 1) - (b.status === "available" ? 0 : 1) || String(a.code).localeCompare(String(b.code)));
  let body;
  if (!tools.length) body = `<div class="empty"><strong>No tools listed yet</strong>The tool room keeper adds tools here. Once they do, you can request them from this page.</div>`;
  else if (!list.length) body = `<div class="empty"><strong>No tools match “${esc(q)}”</strong>Try the tool code or a shorter name.</div>`;
  else body = `<div class="grid">${list.map(t => {
    const pend = myPending(t.id, "out"), other = anyPendingOut(t.id);
    let a;
    if (t.status === "out" && t.holderId === me.id) a = `<span class="pill info">With you</span>`;
    else if (pend) a = `<button class="btn small" type="button" data-cancel="${pend.id}">Cancel request</button>`;
    else if (t.status !== "available") a = `<button class="btn small" type="button" disabled>Not available</button>`;
    else if (calState(t) === "expired") a = `<button class="btn small" type="button" disabled>Cal expired</button>`;
    else if (other) a = `<button class="btn small" type="button" disabled>Requested by someone</button>`;
    else a = `<button class="btn small primary" type="button" data-request="${t.id}">Request</button>`;
    return `<article class="card">${tagHtml(t)}<div><div class="name">${esc(t.name)}</div>
      <div class="meta">${esc([t.category, t.location].filter(Boolean).join(" · ") || "—")}</div></div>
      ${statusPills(t)}<div class="foot">${pend ? `<span class="pill warn">Waiting for keeper</span>` : "<span></span>"}${a}</div></article>`;
  }).join("")}</div>`;
  const uc = unconfirmed().length;
  return (uc ? `<div class="notice">You have ${uc} tool${uc === 1 ? "" : "s"} to confirm. Open <b>My tools</b> and enter the asset number from the sticker.</div>` : "") +
    `<div class="bar"><div><h2>Tools</h2><p class="sub">Request a tool, then collect it from the tool room counter once it's issued.</p></div>
    <input class="search" id="q" type="search" placeholder="Search code or name" value="${esc(q)}" aria-label="Search tools"></div>
    ${cats.length > 2 ? `<div class="chips">${cats.map(c => `<button type="button" class="chip" data-cat="${esc(c)}" aria-pressed="${c === cat}">${esc(c)}</button>`).join("")}</div>` : ""}
    ${body}`;
}
function vMine() {
  const list = tools.filter(t => t.status === "out" && t.holderId === me.id).sort((a, b) => String(a.dueAt).localeCompare(String(b.dueAt)));
  const body = !list.length
    ? `<div class="empty"><strong>You have no tools checked out</strong>Tools the keeper issues to you show up here, with their return date.</div>`
    : `<div class="list">${list.map(t => { const pend = myPending(t.id, "in");
      return `<div class="row${isOverdue(t) || !t.ackAt ? " overdue" : ""}"><div><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b>${statusPills(t)}${ackPill(t)}</div>
      <div class="kv">WO <b>${esc(t.wo || "—")}</b> · Issued <b>${esc(fmtT(t.issuedAt))}</b> · Return by <b>${esc(fmtD(t.dueAt))}</b>${t.calDue ? ` · Cal valid until <b>${esc(fmtD(t.calDue))}</b>` : ""}</div></div>
      <div class="acts">${!t.ackAt ? `<button class="btn small primary" type="button" data-ack="${t.id}">Confirm receipt</button>` : ""}
      ${pend ? `<span class="pill warn">Return pending</span><button class="btn small" type="button" data-cancel="${pend.id}">Cancel</button>`
        : `<button class="btn small${t.ackAt ? " primary" : ""}" type="button" data-return="${t.id}">Return tool</button>`}</div></div>`; }).join("")}</div>`;
  return `<div><h2>My tools</h2><p class="sub">When you collect a tool, confirm receipt with the asset number from its sticker. To give it back, tap “Return tool” and hand it in at the counter.</p></div>${body}`;
}
function reqRow(r, keeper) {
  const t = toolById(r.toolId) || { code: r.toolCode, name: r.toolName };
  const type = r.type === "out" ? `<span class="pill info">Check-out</span>` : `<span class="pill ok">Return</span>`;
  const st = { pending: `<span class="pill warn">Pending</span>`, done: `<span class="pill ok">${r.type === "out" ? "Issued" : "Received"}${r.condition === "damaged" ? " · damaged" : ""}</span>`,
    declined: `<span class="pill bad">Declined</span>`, cancelled: `<span class="pill mute">Cancelled</span>` }[r.status] || "";
  let a = "";
  if (keeper && r.status === "pending") {
    a = r.type === "out"
      ? `<button class="btn small primary" type="button" data-issue="${r.id}">Issue</button><button class="btn small" type="button" data-decline="${r.id}">Decline</button>`
      : `<button class="btn small primary" type="button" data-receive-req="${r.id}">Receive</button>`;
  } else if (!keeper && r.status === "pending") a = `<button class="btn small" type="button" data-cancel="${r.id}">Cancel</button>`;
  const ack = r.type === "out" && r.status === "done" && r.ackAt ? `<span class="pill ok">Receipt confirmed · asset ${esc(r.ackAsset)}</span>` : "";
  return `<div class="row"><div><div class="who">${type}${tagHtml(t)}<b>${esc(t.name || r.toolName || "")}</b>${keeper ? "" : st}${ack}</div>
    <div class="kv">${keeper ? `By <b>${esc(r.techName || person(r.techId))}</b> · ` : ""}WO <b>${esc(r.wo || "—")}</b>${r.type === "out" ? ` · Return by <b>${esc(fmtD(r.dueAt))}</b>` : ""} · ${esc(fmtT(r.createdAt))}${r.note ? ` · “${esc(r.note)}”` : ""}${r.reason ? ` · ${r.status === "declined" ? "Reason" : "Remark"}: ${esc(r.reason)}` : ""}${keeper && r.handledBy ? ` · Handled by <b>${esc(person(r.handledBy, "—"))}</b>` : ""}</div></div>
    <div class="acts">${keeper && r.status !== "pending" ? st : ""}${a}</div></div>`;
}
function vMyRequests() {
  const list = reqs.filter(r => r.techId === me.id);
  return `<div><h2>My requests</h2><p class="sub">Every check-out and return you've asked for, newest first.</p></div>` +
    (list.length ? `<div class="list">${list.map(r => reqRow(r, false)).join("")}</div>` : `<div class="empty"><strong>No requests yet</strong>Pick a tool from the Tools tab to send your first request.</div>`);
}

/* ---------- keeper views ---------- */
function keeperStats() {
  const out = tools.filter(t => t.status === "out");
  const od = out.filter(isOverdue).length, cal = tools.filter(t => calState(t) === "expired").length, p = pending().length;
  return `<div class="stats"><div class="stat${p ? " alert" : ""}"><b>${p}</b><span>Waiting</span></div>
    <div class="stat"><b>${out.length}</b><span>Checked out</span></div>
    <div class="stat${od ? " alert" : ""}"><b>${od}</b><span>Overdue</span></div>
    <div class="stat${cal ? " alert" : ""}"><b>${cal}</b><span>Cal expired</span></div></div>`;
}
function vQueue() {
  const list = pending().slice().sort((a, b) => a.createdAt - b.createdAt);
  return keeperStats() + `<div><h2>Requests</h2><p class="sub">Oldest first. Issue when the technician is at the counter; receive when the tool is in your hand.</p></div>` +
    (list.length ? `<div class="list">${list.map(r => reqRow(r, true)).join("")}</div>` : `<div class="empty"><strong>No requests waiting</strong>New check-out and return requests from technicians appear here automatically.</div>`);
}
function vOut() {
  const list = tools.filter(t => t.status === "out").sort((a, b) => String(a.dueAt).localeCompare(String(b.dueAt)));
  return `<div><h2>Checked out</h2><p class="sub">Who holds what, sorted by return date. Overdue tools are outlined in red.</p></div>` +
    (list.length ? `<div class="list">${list.map(t => `<div class="row${isOverdue(t) ? " overdue" : ""}"><div><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b>${statusPills(t)}${ackPill(t)}</div>
      <div class="kv">Holder <b>${esc(t.holderName || person(t.holderId))}</b> · WO <b>${esc(t.wo || "—")}</b> · Issued <b>${esc(fmtT(t.issuedAt))}</b> · Return by <b>${esc(fmtD(t.dueAt))}</b></div></div>
      <div class="acts"><button class="btn small primary" type="button" data-receive-tool="${t.id}">Receive</button></div></div>`).join("")}</div>`
      : `<div class="empty"><strong>Every tool is in the crib</strong>Issued tools are listed here until they come back.</div>`);
}
function vInventory() {
  const list = tools.filter(t => !q || `${t.code} ${t.name} ${t.category} ${t.location}`.toLowerCase().includes(q.toLowerCase()));
  const head = `<div class="bar"><div><h2>Inventory</h2><p class="sub">${tools.length} tools. Calibration-controlled tools with an expired date can't be issued.${tools.some(t => !t.assetNo) ? " Tools without an asset number fall back to the tool code for receipt confirmation." : ""}</p></div>
    <div class="chips"><input class="search" id="q" type="search" placeholder="Search" value="${esc(q)}" aria-label="Search inventory">
    <button class="btn" type="button" data-bulk>Paste a list</button><button class="btn primary" type="button" data-add>Add tool</button></div></div>`;
  if (!tools.length) return head + `<div class="empty"><strong>Start your tool list</strong>Add tools one by one, or paste your existing register (code, name, category, location, cal due date).<br><button class="btn primary" type="button" data-bulk>Paste a list</button></div>`;
  return head + `<div class="tablewrap"><table><thead><tr><th>Code</th><th>Asset no.</th><th>Tool</th><th>Category</th><th>Location</th><th>Cal due</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map(t => `<tr><td>${tagHtml(t)}</td><td class="num">${esc(t.assetNo || "—")}</td><td>${esc(t.name)}</td><td>${esc(t.category || "—")}</td><td>${esc(t.location || "—")}</td><td class="num">${esc(t.calDue || "—")}</td>
    <td>${statusPills(t)}</td><td><div class="chips" style="justify-content:flex-end">
    ${t.status === "available" ? `<button class="btn small primary" type="button" data-walkup="${t.id}"${calState(t) === "expired" ? " disabled" : ""}>Issue</button>` : ""}
    <button class="btn small" type="button" data-edit="${t.id}">Edit</button></div></td></tr>`).join("")}
    </tbody></table></div>`;
}
function vLog() {
  const list = reqs.filter(r => r.status !== "pending").slice(0, 300);
  return `<div class="bar"><div><h2>Log</h2><p class="sub">Every issue, return, decline and cancellation, newest first. Use it to trace a tool to a work order.</p></div>
    <a class="btn" href="api/export/log.csv">Download full log (CSV)</a></div>` +
    (list.length ? `<div class="list">${list.map(r => reqRow(r, true)).join("")}</div>` : `<div class="empty"><strong>Nothing logged yet</strong>Completed check-outs and returns are recorded here automatically.</div>`);
}
function vUsers() {
  return `<div class="bar"><div><h2>Users</h2><p class="sub">Technicians sign in to request and return tools. Keepers run the counter and manage this list.</p></div>
    <button class="btn primary" type="button" data-adduser>Add user</button></div>
    <div class="tablewrap"><table><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody>
    ${users.map(u => `<tr class="${u.active ? "" : "inactive"}"><td>${esc(u.name)}</td><td class="num">${esc(u.username)}</td>
      <td>${u.role === "keeper" ? `<span class="pill info">Keeper</span>` : `<span class="pill mute">Technician</span>`}</td>
      <td>${u.active ? `<span class="pill ok">Active</span>` : `<span class="pill mute">Deactivated</span>`}</td>
      <td><div class="chips" style="justify-content:flex-end"><button class="btn small" type="button" data-resetpw="${u.id}">Reset password</button>
      ${u.id !== me.id ? `<button class="btn small" type="button" data-toggleuser="${u.id}">${u.active ? "Deactivate" : "Reactivate"}</button>` : ""}</div></td></tr>`).join("")}
    </tbody></table></div>`;
}

function draw() {
  if (!me) return;
  drawHeader();
  const v = role();
  const view = v === "keeper"
    ? { queue: vQueue, out: vOut, inventory: vInventory, log: vLog, users: vUsers }[tab.keeper]
    : { tools: vToolsTech, mine: vMine, requests: vMyRequests }[tab.tech];
  const focusQ = document.activeElement && document.activeElement.id === "q";
  const pos = focusQ ? document.activeElement.selectionStart : 0;
  $("#main").innerHTML = view();
  if (focusQ && $("#q")) { $("#q").focus(); try { $("#q").setSelectionRange(pos, pos); } catch (e) {} }
}

/* ---------- dialogs ---------- */
function openDlg(html, onSubmit) {
  const f = $("#dlgForm"); f.innerHTML = html;
  f.onsubmit = async ev => {
    ev.preventDefault();
    const sub = f.querySelector("[type=submit]"); if (sub) sub.disabled = true;
    try { const ok = await onSubmit(new FormData(f), f); if (ok !== false) $("#dlg").close(); }
    finally { if (sub) sub.disabled = false; }
  };
  f.querySelectorAll("[data-close]").forEach(b => b.onclick = () => $("#dlg").close());
  $("#dlg").showModal();
  const first = f.querySelector("input:not([readonly]),select,textarea"); if (first) first.focus();
}
const cancelBtn = `<button class="btn" type="button" data-close>Cancel</button>`;

function dlgRequest(t) {
  openDlg(`<h3>Request tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Work order / job number<input name="wo" required maxlength="40" placeholder="e.g. WO-24811"></label>
    <label>Return by${t.calDue ? ` <span class="hint">No later than the calibration due date, ${esc(fmtD(t.calDue))}</span>` : ""}<input name="due" type="date" required value="${today()}" min="${today()}"${t.calDue ? ` max="${esc(t.calDue)}"` : ""}></label>
    <label>Note for the keeper <span class="hint">Optional</span><input name="note" maxlength="140" placeholder="e.g. Bay 3, QSK60 overhaul"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Send request</button></div>`,
    fd => act(() => api("requests", { type: "out", toolId: t.id, wo: fd.get("wo"), dueAt: fd.get("due"), note: fd.get("note") }), "Request sent. Collect the tool at the counter."));
}
function dlgAck(t) {
  openDlg(`<h3>Confirm receipt</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Asset number from the sticker on the tool<input name="assetNo" id="ackAsset" required maxlength="40" autocomplete="off" placeholder="Read it off the sticker"></label>
    <div class="notice" id="pledge" style="color:var(--ink);background:var(--surface-2);border:1px solid var(--line)">${pledgeHtml(t, "")}</div>
    <label style="flex-direction:row;align-items:flex-start;gap:10px;color:var(--ink);font-weight:500"><input type="checkbox" name="agree" required style="width:auto;margin-top:3px">I have read this statement and accept responsibility for this tool.</label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Confirm and accept</button></div>`,
    fd => act(() => api(`tools/${t.id}/ack`, { assetNo: fd.get("assetNo"), agree: fd.get("agree") === "on" }), "Receipt confirmed. The tool is now in your custody."));
  $("#ackAsset").addEventListener("input", e => { $("#pledge").innerHTML = pledgeHtml(t, e.target.value.trim()); });
}
function dlgReturn(t) {
  openDlg(`<h3>Return tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Anything the keeper should know? <span class="hint">Optional — e.g. damage, missing parts</span><input name="note" maxlength="140"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Send return</button></div>`,
    fd => act(() => api("requests", { type: "in", toolId: t.id, note: fd.get("note") }), "Return sent. Hand the tool in at the counter."));
}
function dlgReceive(t, r) {
  openDlg(`<h3>Receive tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <div class="kv">From <b>${esc(t.holderName || person(t.holderId))}</b> · WO <b>${esc(t.wo || "—")}</b></div>
    ${r && r.note ? `<div class="notice">Technician note: ${esc(r.note)}</div>` : ""}
    <label>Condition<select name="cond"><option value="good">Good — back in the crib</option><option value="damaged">Damaged — move to out of service</option></select></label>
    <label>Remark <span class="hint">Optional</span><input name="remark" maxlength="140"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Confirm received</button></div>`,
    fd => act(() => api(`tools/${t.id}/receive`, { condition: fd.get("cond"), remark: fd.get("remark") }),
      fd.get("cond") === "damaged" ? "Received and moved to out of service." : "Received. Tool is back in the crib."));
}
function dlgDecline(r) {
  openDlg(`<h3>Decline request</h3><label>Reason the technician will see<input name="reason" required maxlength="140" placeholder="e.g. Tool reserved for SRC job"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Decline</button></div>`,
    fd => act(() => api(`requests/${r.id}/decline`, { reason: fd.get("reason") }), "Declined."));
}
function dlgWalkup(t) {
  const opts = technicians.map(u => `<option value="${u.id}">${esc(u.name)} (${esc(u.username)})</option>`).join("");
  openDlg(`<h3>Issue at the counter</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Technician<select name="techId" id="techSel"><option value="">— Choose from the list —</option>${opts}<option value="other">Someone without an account…</option></select></label>
    <label id="otherWrap" hidden>Name <span class="hint">Without an account they can't confirm receipt in the app. Get a paper sign-off.</span><input name="name" maxlength="80" placeholder="Full name"></label>
    <div class="two"><label>Work order<input name="wo" required maxlength="40"></label>
    <label>Return by<input name="due" type="date" required value="${today()}" min="${today()}"${t.calDue ? ` max="${esc(t.calDue)}"` : ""}></label></div>
    <p class="hint">The technician confirms receipt on their phone with the asset number from the sticker.</p>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Issue tool</button></div>`,
    fd => {
      const sel = fd.get("techId");
      if (!sel) { toast("Choose the technician."); return false; }
      return act(() => api(`tools/${t.id}/issue`, { techId: sel === "other" ? null : Number(sel), name: fd.get("name"), wo: fd.get("wo"), dueAt: fd.get("due") }), "Tool issued.");
    });
  $("#techSel").addEventListener("change", e => { $("#otherWrap").hidden = e.target.value !== "other"; });
}
function dlgTool(t) {
  const n = !t; t = t || {};
  openDlg(`<h3>${n ? "Add tool" : "Edit tool"}</h3>
    <div class="two"><label>Tool code<input name="code" required maxlength="30" value="${esc(t.code || "")}" ${n ? "" : "readonly"} placeholder="e.g. TW-018"></label>
    <label>Category<input name="category" maxlength="40" value="${esc(t.category || "")}" placeholder="e.g. Torque wrench" list="catList"></label></div>
    <datalist id="catList">${[...new Set(tools.map(x => x.category).filter(Boolean))].map(c => `<option value="${esc(c)}">`).join("")}</datalist>
    <label>Asset number <span class="hint">As printed on the asset sticker. Technicians type it to confirm receipt; they never see it in the app.</span><input name="assetNo" maxlength="40" value="${esc(t.assetNo || "")}" placeholder="e.g. CA-DMM-00418"></label>
    <label>Tool name<input name="name" required maxlength="80" value="${esc(t.name || "")}" placeholder="e.g. Torque wrench 40–200 Nm, 1/2&quot; drive"></label>
    <div class="two"><label>Location<input name="location" maxlength="40" value="${esc(t.location || "")}" placeholder="e.g. Cabinet B, drawer 2"></label>
    <label>Calibration due <span class="hint">Leave empty if not calibrated</span><input name="calDue" type="date" value="${esc(t.calDue || "")}"></label></div>
    ${!n && t.status !== "out" ? `<label>Status<select name="status"><option value="available"${t.status === "available" ? " selected" : ""}>Available</option><option value="service"${t.status === "service" ? " selected" : ""}>Out of service</option></select></label>` : ""}
    <div class="dacts">${!n && t.status !== "out" ? `<button class="btn danger" type="button" id="del">Remove tool</button><span class="spacer"></span>` : ""}${cancelBtn}<button class="btn primary" type="submit">${n ? "Add tool" : "Save"}</button></div>`,
    fd => {
      const body = Object.fromEntries(fd.entries());
      return n ? act(() => api("tools", body), "Tool added.") : act(() => api(`tools/${t.id}`, body, "PUT"), "Saved.");
    });
  const del = $("#del");
  if (del) del.onclick = async () => {
    if (!del.dataset.armed) { del.dataset.armed = "1"; del.textContent = "Tap again to remove"; return; }
    if (await act(() => api(`tools/${t.id}`, {}, "DELETE"), "Tool removed.")) $("#dlg").close();
  };
}
function dlgBulk() {
  openDlg(`<h3>Paste a tool list</h3>
    <label>One tool per line: code, name, category, location, cal due (YYYY-MM-DD), asset number
    <textarea name="rows" required placeholder="TW-018, Torque wrench 40-200 Nm, Torque wrench, Cabinet B, 2027-03-31, CA-00418&#10;DI-004, Dial indicator 0-10 mm, Measuring, Drawer 4, 2027-01-15, CA-00377&#10;PL-031, Bearing puller set, Pullers, Rack 2, , CA-00502"></textarea>
    <span class="hint">Copy rows straight from Excel (tabs work too). Existing codes are updated, not duplicated.</span></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Import</button></div>`,
    fd => act(() => api("tools/bulk", { rows: fd.get("rows") }),
      r => `Added ${r.added}, updated ${r.updated}${r.skipped ? `, skipped ${r.skipped}` : ""}.`));
}
function dlgAddUser() {
  openDlg(`<h3>Add user</h3>
    <label>Full name<input name="name" required maxlength="80"></label>
    <div class="two"><label>Username<input name="username" required maxlength="40" pattern="[A-Za-z0-9._\\-]{3,40}" placeholder="e.g. a.rahman"></label>
    <label>Role<select name="role"><option value="tech">Technician</option><option value="keeper">Tool room keeper</option></select></label></div>
    <label>Temporary password <span class="hint">At least 8 characters. Ask them to change it after signing in.</span><input name="password" required minlength="8"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Add user</button></div>`,
    fd => act(async () => { await api("users", Object.fromEntries(fd.entries())); users = await api("users"); }, "User added."));
}
function dlgResetPw(u) {
  openDlg(`<h3>Reset password</h3><p class="sub">${esc(u.name)} (${esc(u.username)}) will be signed out everywhere.</p>
    <label>New password<input name="password" required minlength="8"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Reset</button></div>`,
    fd => act(() => api(`users/${u.id}`, { password: fd.get("password") }, "PUT"), "Password reset."));
}
function dlgMyPw() {
  openDlg(`<h3>Change password</h3>
    <label>Current password<input name="current" type="password" required autocomplete="current-password"></label>
    <label>New password<input name="password" type="password" required minlength="8" autocomplete="new-password"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Change</button></div>`,
    fd => act(() => api("me/password", { current: fd.get("current"), password: fd.get("password") }), "Password changed."));
}

/* ---------- events ---------- */
document.addEventListener("click", async ev => {
  const b = ev.target.closest("button"); if (!b || !me) return;
  const d = b.dataset;
  if (d.tab) { tab[role()] = d.tab; q = ""; if (d.tab === "users") users = await api("users").catch(() => []); draw(); window.scrollTo(0, 0); return; }
  if (d.cat) { cat = d.cat; draw(); return; }
  if (d.logout !== undefined) { await api("logout", {}).catch(() => {}); showLogin(); return; }
  if (d.pw !== undefined) return dlgMyPw();
  if (d.request) dlgRequest(toolById(d.request));
  else if (d.return) dlgReturn(toolById(d.return));
  else if (d.ack) dlgAck(toolById(d.ack));
  else if (d.cancel) act(() => api(`requests/${d.cancel}/cancel`, {}), "Request cancelled.");
  else if (d.issue) { b.disabled = true; await act(() => api(`requests/${d.issue}/issue`, {}), "Tool issued."); b.disabled = false; }
  else if (d.decline) dlgDecline(reqs.find(x => x.id === Number(d.decline)));
  else if (d.receiveReq) { const r = reqs.find(x => x.id === Number(d.receiveReq)), t = r && toolById(r.toolId);
    if (!t) return toast("This tool is no longer in the inventory."); dlgReceive(t, r); }
  else if (d.receiveTool) dlgReceive(toolById(d.receiveTool), null);
  else if (d.walkup) dlgWalkup(toolById(d.walkup));
  else if (d.edit) dlgTool(toolById(d.edit));
  else if (d.add !== undefined) dlgTool(null);
  else if (d.bulk !== undefined) dlgBulk();
  else if (d.adduser !== undefined) dlgAddUser();
  else if (d.resetpw) dlgResetPw(users.find(u => u.id === Number(d.resetpw)));
  else if (d.toggleuser) { const u = users.find(x => x.id === Number(d.toggleuser));
    act(async () => { await api(`users/${u.id}`, { active: !u.active }, "PUT"); users = await api("users"); }, u.active ? "User deactivated." : "User reactivated."); }
});
document.addEventListener("input", ev => { if (ev.target.id === "q") { q = ev.target.value; draw(); } });

/* ---------- boot ---------- */
start().catch(() => showLogin());
