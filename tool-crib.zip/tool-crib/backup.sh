#!/usr/bin/env bash
# Daily backup of the Tool Crib database. Keeps the last 30 days.
# Uses SQLite's own backup, so it's safe while the site is running.
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="${BACKUP_DIR:-/opt/backups}"
mkdir -p "$BACKUP_DIR"
cd "$APP_DIR"
OUT="$BACKUP_DIR/toolcrib-$(date +%F).db"
node --input-type=module -e "
import Database from 'better-sqlite3';
const db = new Database(process.argv[1], { readonly: true });
await db.backup(process.argv[2]);
db.close();
" "${DB_PATH:-$APP_DIR/data/toolcrib.db}" "$OUT"
find "$BACKUP_DIR" -name 'toolcrib-*.db' -mtime +30 -delete
echo "Backup saved: $OUT"
