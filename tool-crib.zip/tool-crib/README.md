# Tool Crib — Check-out & Return

Author: Joud Alnasser

A small web app for the tool room. Two kinds of users:

- **Tool room keeper** — issues and receives tools, manages the inventory and user accounts, sees the full log and downloads it as CSV.
- **Technician** — requests a tool against a work order, sees what they hold, and sends returns.

Tools with an expired calibration date cannot be issued, and a return date can't be later than the tool's calibration due date.

**Receipt confirmation:** after the keeper issues a tool, the technician must confirm receipt in the app by typing the **asset number from the sticker** on the tool and accepting a responsibility pledge (return by the agreed date and before calibration expires; responsible for loss, damage or misuse). The app never shows technicians the asset number, so they have to read it off the tool. The time, the number typed, and the exact pledge wording are saved and included in the CSV log. Until confirmed, the keeper sees the tool as "Awaiting technician confirmation".

## What's inside

| File | Purpose |
|---|---|
| `server.js` | The server: logins, rules, and the database (SQLite) |
| `public/` | The website itself (`index.html`, `app.js`, `style.css`) |
| `package.json` | The list of things Node.js needs to install |
| `.env.example` | Settings template (first keeper login, port, etc.) |
| `Dockerfile` | Optional: run it as a Docker container |

Everything is stored in one file: `data/toolcrib.db`. **Back up that file** — it is your whole tool register and log.

---

## Option A — Your own server (VPS), recommended

### Quick way: one command

On a fresh **Ubuntu 24.04** server, upload the ZIP to `/opt/`, then as root:

```bash
cd /opt && apt-get install -y unzip && unzip tool-crib.zip && bash /opt/tool-crib/setup.sh
```

It asks for the keeper username and password, then installs everything, turns on HTTPS, the firewall and a daily backup (`backup.sh`, kept 30 days in `/opt/backups`). Without your own domain it gives you a free address like `https://tools-1-2-3-4.sslip.io`.

The manual steps below do the same thing, if you prefer.

Works on any Linux server (Ubuntu 22.04/24.04): DigitalOcean, Hostinger VPS, AWS Lightsail, Azure VM, or a company server.

### 1. Install Node.js 22 on the server

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs build-essential
node -v   # should show v22.x
```

### 2. Upload the app

From your computer (replace the IP):

```bash
scp tool-crib.zip root@YOUR_SERVER_IP:/opt/
```

Then on the server:

```bash
cd /opt && sudo apt-get install -y unzip && unzip tool-crib.zip && cd tool-crib
npm ci --omit=dev
cp .env.example .env
nano .env        # set ADMIN_PASSWORD to a strong password, save with Ctrl+O, exit with Ctrl+X
```

### 3. Keep it running (PM2)

```bash
sudo npm install -g pm2
pm2 start npm --name tool-crib -- start
pm2 save
pm2 startup      # run the command it prints, so the app restarts after a reboot
```

Test it: open `http://YOUR_SERVER_IP:3000` and sign in with the keeper account from `.env`.

### 4. Add a domain and HTTPS (Caddy — automatic certificate)

Point your domain (for example `tools.yourdomain.com`) to the server's IP with an **A record**, then:

```bash
sudo apt-get install -y caddy
echo 'tools.yourdomain.com {
  reverse_proxy localhost:3000
}' | sudo tee /etc/caddy/Caddyfile
sudo systemctl restart caddy
```

Then set `SECURE_COOKIE=true` in `.env` and run `pm2 restart tool-crib`.

Close port 3000 to the outside so only HTTPS is used:

```bash
sudo ufw allow OpenSSH && sudo ufw allow 80 && sudo ufw allow 443 && sudo ufw enable
```

### 5. Daily backup (recommended)

```bash
mkdir -p /opt/backups
chmod +x /opt/tool-crib/backup.sh
(crontab -l 2>/dev/null; echo '0 2 * * * /opt/tool-crib/backup.sh >> /var/log/toolcrib-backup.log 2>&1') | crontab -
```

### Updating the app later

Upload the new files over the old ones (keep the `data/` folder and `.env`), then:

```bash
cd /opt/tool-crib && npm ci --omit=dev && pm2 restart tool-crib
```

---

## Option B — Hosting platform (no server to manage)

Any platform that runs Node.js **and gives a persistent disk** works (Render, Railway, Fly.io, Azure App Service).

1. Put this folder in a GitHub repository.
2. Create a new web service from that repository.
   - Build command: `npm ci --omit=dev`
   - Start command: `npm start`
3. Add a persistent disk/volume mounted at `/data`, and set these environment variables:
   - `DB_PATH=/data/toolcrib.db`
   - `ADMIN_PASSWORD=` a strong password
   - `SECURE_COOKIE=true`
   - `TZ=Asia/Riyadh`

Without a persistent disk the database is wiped on every restart.

---

## Option C — Docker

```bash
docker build -t tool-crib .
docker run -d --name tool-crib -p 3000:3000 \
  -e ADMIN_PASSWORD='a-strong-password' \
  -v toolcrib-data:/app/data --restart unless-stopped tool-crib
```

---

## First sign-in

1. Sign in as the keeper (username `keeper` unless you changed `ADMIN_USERNAME`).
2. Click **Password** at the top and change it.
3. **Users** tab → add each technician (and other keepers) with a temporary password.
4. **Inventory** tab → **Paste a list** → paste your tool register from Excel:
   `code, name, category, location, cal due (YYYY-MM-DD), asset number`
   Fill in the asset number for every tool: it's what technicians type to confirm receipt. If it's empty, the tool code is used instead.

If you started without setting `ADMIN_PASSWORD`, a random password is printed once in the server log (`pm2 logs tool-crib`).

## Notes

- Before putting company data on a server outside Cummins, get IT's approval.
- Session cookies last 14 days. Deactivating a user or resetting their password signs them out immediately.
- After 8 wrong passwords from one address, sign-in is paused for 5 minutes.
