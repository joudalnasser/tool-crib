// Tool Crib — check-out & return server
// Node.js + Express + SQLite. One process, one database file, no other services.
import express from "express";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "toolcrib.db");
const SECURE_COOKIE = process.env.SECURE_COOKIE === "true"; // set true when served over HTTPS
const SESSION_DAYS = 14;

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('keeper','tech')),
  passHash TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  createdAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  userId INTEGER NOT NULL,
  expiresAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tools (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT '',
  location TEXT NOT NULL DEFAULT '',
  calDue TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','out','service')),
  holderId INTEGER,
  holderName TEXT NOT NULL DEFAULT '',
  wo TEXT NOT NULL DEFAULT '',
  issuedAt INTEGER,
  dueAt TEXT NOT NULL DEFAULT '',
  createdAt INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL CHECK (type IN ('out','in')),
  toolId INTEGER NOT NULL,
  toolCode TEXT NOT NULL,
  toolName TEXT NOT NULL,
  techId INTEGER,
  techName TEXT NOT NULL DEFAULT '',
  wo TEXT NOT NULL DEFAULT '',
  dueAt TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL CHECK (status IN ('pending','done','declined','cancelled')),
  condition TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL DEFAULT '',
  createdAt INTEGER NOT NULL,
  handledAt INTEGER,
  handledBy INTEGER
);
CREATE INDEX IF NOT EXISTS idx_req_status ON requests(status);
CREATE INDEX IF NOT EXISTS idx_req_created ON requests(createdAt);
`);

// Columns added after the first release — added in place so existing databases keep their data.
const addCol = (table, col, def) => {
  if (!db.prepare(`PRAGMA table_info(${table})`).all().some(c => c.name === col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);
};
addCol("tools", "assetNo", "TEXT NOT NULL DEFAULT ''");   // number on the asset sticker
addCol("tools", "reqId", "INTEGER");                      // the check-out record for the current holder
addCol("tools", "ackAt", "INTEGER");                      // when the holder confirmed receipt
addCol("requests", "ackAt", "INTEGER");
addCol("requests", "ackAsset", "TEXT NOT NULL DEFAULT ''");
addCol("requests", "pledge", "TEXT NOT NULL DEFAULT ''"); // exact wording the technician accepted
addCol("requests", "pledgeAt", "INTEGER");                      // when the request statement was accepted
addCol("requests", "ackPledge", "TEXT NOT NULL DEFAULT ''");
addCol("requests", "location", "TEXT NOT NULL DEFAULT ''");    // where the keeper put the tool on return   // statement accepted again at receipt, with the asset number
// Calibration register fields (mirror the controlled calibration form)
for (const c of ["brand", "model", "serialNo", "description", "rangeText", "unit", "resolution", "tolPlus", "tolMinus",
  "lastCal", "certNo", "lab", "errPlus", "errMinus", "disposition", "remarks"]) addCol("tools", c, "TEXT NOT NULL DEFAULT ''");
addCol("tools", "freqMonths", "INTEGER NOT NULL DEFAULT 12");
addCol("tools", "calStatus", "TEXT NOT NULL DEFAULT 'ok'"); // ok | at_lab | quarantine | scrapped
db.exec(`
CREATE TABLE IF NOT EXISTS cal_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  toolId INTEGER NOT NULL,
  toolCode TEXT NOT NULL,
  type TEXT NOT NULL,           -- imported | calibrated | failed | sent | quarantined | released | scrapped
  calDate TEXT NOT NULL DEFAULT '',
  dueDate TEXT NOT NULL DEFAULT '',
  certNo TEXT NOT NULL DEFAULT '',
  lab TEXT NOT NULL DEFAULT '',
  errPlus TEXT NOT NULL DEFAULT '',
  errMinus TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  at INTEGER NOT NULL,
  byId INTEGER
);
CREATE INDEX IF NOT EXISTS idx_cal_tool ON cal_events(toolId);
CREATE TABLE IF NOT EXISTS branches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  createdAt INTEGER NOT NULL
);
`);

/* ---------- branches + Parts Specialist (multi-branch upgrade) ---------- */
if (!db.prepare("SELECT 1 FROM branches LIMIT 1").get()) {
  const names = (process.env.BRANCHES || "Dammam,Riyadh,Jeddah").split(",").map(s => s.trim()).filter(Boolean);
  const ins = db.prepare("INSERT INTO branches (name,createdAt) VALUES (?,?)");
  names.forEach(n => ins.run(n, Date.now()));
}
const firstBranch = db.prepare("SELECT id FROM branches ORDER BY id LIMIT 1").get().id;
const tableSql = n => db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name=?").get(n)?.sql || "";
const cols = n => db.prepare(`PRAGMA table_info(${n})`).all().map(c => c.name);
// Rebuild a table in place (SQLite can't change CHECK/UNIQUE constraints with ALTER).
function rebuild(name, ddl, fill) {
  db.transaction(() => {
    db.exec(`ALTER TABLE ${name} RENAME TO ${name}_old`);
    db.exec(ddl);
    const keep = cols(name).filter(c => cols(`${name}_old`).includes(c));
    db.exec(`INSERT INTO ${name} (${keep.join(",")}) SELECT ${keep.join(",")} FROM ${name}_old`);
    db.exec(`DROP TABLE ${name}_old`);
    fill && fill();
  })();
}
if (!tableSql("users").includes("'super'")) {
  rebuild("users", `CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('super','specialist','keeper','tech')),
    branchId INTEGER,
    passHash TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    createdAt INTEGER NOT NULL)`, () => {
    db.prepare("UPDATE users SET branchId=? WHERE branchId IS NULL").run(firstBranch);
    // The original admin (first keeper) becomes the Super User (all branches, all permissions).
    if (!db.prepare("SELECT 1 FROM users WHERE role='super'").get()) {
      const first = db.prepare("SELECT id FROM users WHERE role IN ('specialist','keeper') ORDER BY id LIMIT 1").get();
      if (first) db.prepare("UPDATE users SET role='super', branchId=NULL WHERE id=?").run(first.id);
    }
    db.prepare("UPDATE users SET branchId=? WHERE role<>'super' AND branchId IS NULL").run(firstBranch);
  });
}
if (!cols("tools").includes("branchId")) {
  const T = (k, d) => `${k} ${d}`;
  const textCols = ["assetNo", "brand", "model", "serialNo", "description", "rangeText", "unit", "resolution", "tolPlus", "tolMinus",
    "lastCal", "certNo", "lab", "errPlus", "errMinus", "disposition", "remarks"].map(c => T(c, "TEXT NOT NULL DEFAULT ''")).join(",\n    ");
  rebuild("tools", `CREATE TABLE tools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branchId INTEGER NOT NULL DEFAULT ${firstBranch},
    code TEXT NOT NULL COLLATE NOCASE,
    name TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT '',
    location TEXT NOT NULL DEFAULT '',
    calDue TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','out','service')),
    holderId INTEGER,
    holderName TEXT NOT NULL DEFAULT '',
    wo TEXT NOT NULL DEFAULT '',
    issuedAt INTEGER,
    dueAt TEXT NOT NULL DEFAULT '',
    reqId INTEGER,
    ackAt INTEGER,
    ${textCols},
    freqMonths INTEGER NOT NULL DEFAULT 12,
    calStatus TEXT NOT NULL DEFAULT 'ok',
    createdAt INTEGER NOT NULL)`);
}
db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_tools_branch_code ON tools(branchId, code COLLATE NOCASE)");
addCol("requests", "branchId", "INTEGER");
db.prepare("UPDATE requests SET branchId=(SELECT branchId FROM tools WHERE tools.id=requests.toolId) WHERE branchId IS NULL").run();
db.prepare("UPDATE requests SET branchId=? WHERE branchId IS NULL").run(firstBranch);
db.exec(`CREATE TRIGGER IF NOT EXISTS trg_req_branch AFTER INSERT ON requests WHEN NEW.branchId IS NULL
  BEGIN UPDATE requests SET branchId=(SELECT branchId FROM tools WHERE id=NEW.toolId) WHERE id=NEW.id; END`);

/* ---------- passwords & tokens ---------- */
const sha = v => crypto.createHash("sha256").update(String(v)).digest("hex");
// Old plain-text session tokens (64 hex chars, not hashes of anything) are dropped once on upgrade: users sign in again.
if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='meta'").get()) db.exec("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)");
if (!db.prepare("SELECT 1 FROM meta WHERE k='sessions_hashed'").get()) { db.exec("DELETE FROM sessions"); db.prepare("INSERT INTO meta VALUES ('sessions_hashed','1')").run(); }
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(pw, salt, 64);
  return salt.toString("hex") + ":" + hash.toString("hex");
}
function checkPassword(pw, stored) {
  const [s, h] = String(stored).split(":");
  if (!s || !h) return false;
  const hash = crypto.scryptSync(pw, Buffer.from(s, "hex"), 64);
  const want = Buffer.from(h, "hex");
  return want.length === hash.length && crypto.timingSafeEqual(want, hash);
}

/* ---------- first admin (Super User, all branches) ---------- */
if (!db.prepare("SELECT 1 FROM users WHERE role='super' LIMIT 1").get()) {
  const username = process.env.ADMIN_USERNAME || "admin";
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString("base64url");
  db.prepare("INSERT INTO users (username,name,role,branchId,passHash,createdAt) VALUES (?,?,?,NULL,?,?)")
    .run(username, process.env.ADMIN_NAME || "Super User", "super", hashPassword(password), Date.now());
  console.log("\n================ FIRST LOGIN ================");
  console.log(`  Username: ${username}`);
  console.log(`  Password: ${process.env.ADMIN_PASSWORD ? "(the ADMIN_PASSWORD you set)" : password}`);
  console.log("  Change it after you sign in (Users tab).");
  console.log("=============================================\n");
}

/* ---------- helpers ---------- */
const now = () => Date.now();
const today = () => new Date().toLocaleDateString("en-CA", { timeZone: process.env.TZ || "Asia/Riyadh" });
const str = (v, max = 140) => String(v ?? "").trim().slice(0, max);
const isDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || ""));
const calExpired = t => !!t.calDue && t.calDue < today();
const normAsset = v => String(v || "").toUpperCase().replace(/[\s\-_./]/g, "");
// Same wording the technician sees on screen; stored with the record they confirm.
const pledgeText = (t, name, dueAt, asset) =>
  `I, ${name}, confirm that I have received tool ${t.code} (${t.name}), asset number ${asset}, ` +
  `and checked it against its asset sticker. I will return it to the tool room by ${dueAt || "the agreed date"}` +
  (t.calDue ? ` and before its calibration expires on ${t.calDue}` : "") +
  `. While this tool is in my custody I am responsible for it, including its loss, damage or misuse.`;
// Accepted when the technician requests the tool (no asset number yet).
const requestPledgeText = (t, name, dueAt, wo) =>
  `I, ${name}, request tool ${t.code} (${t.name}) for work order ${wo}. When it is handed to me I will check it against its asset sticker. ` +
  `I will return it to the tool room by ${dueAt}` + (t.calDue ? ` and before its calibration expires on ${t.calDue}` : "") +
  `. While this tool is in my custody I am responsible for it, including its loss, damage or misuse.`;
const dueCheck = (t, dueAt) => { if (t.calDue && dueAt > t.calDue) bad(`The return date can't be after the calibration due date (${t.calDue}).`); };
const addMonths = (iso, n) => {
  const [y, m, d] = iso.split("-").map(Number);
  const t = new Date(Date.UTC(y, m - 1 + n, 1));
  const last = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
  t.setUTCDate(Math.min(d, last));
  return t.toISOString().slice(0, 10);
};
// "22/11/21" or "22/11/2021" -> "2021-11-22"
const fromDMY = v => {
  const m = String(v || "").trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})$/);
  if (!m) return "";
  const y = m[3].length === 2 ? "20" + m[3] : m[3];
  return `${y}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
};
const toDMY = iso => isDate(iso) ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(2, 4)}` : "";
const categoryFor = d => {
  d = String(d).toLowerCase();
  if (d.includes("torque")) return "Torque";
  if (/micrometer|caliper|bore|dial indicator|dial gauge/.test(d)) return "Dimensional";
  if (/multimeter|clamp|insulation|phase rotation|proving/.test(d)) return "Electrical";
  if (/pressure|vacuum/.test(d)) return "Pressure & Vacuum";
  if (/temperature|thermometer|anemometer/.test(d)) return "Temperature";
  return "Test & Inspection";
};
const calEvent = (t, type, f, byId) => db.prepare(`INSERT INTO cal_events (toolId,toolCode,type,calDate,dueDate,certNo,lab,errPlus,errMinus,note,at,byId)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(t.id, t.code, type, f.calDate || "", f.dueDate || "", f.certNo || "", f.lab || "",
  f.errPlus || "", f.errMinus || "", f.note || "", now(), byId ?? null);
const cancelPendingOut = (t, byId, why) => db.prepare(
  "UPDATE requests SET status='declined', reason=?, handledAt=?, handledBy=? WHERE toolId=? AND type='out' AND status='pending'")
  .run(why, now(), byId, t.id);
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = msg => { throw new HttpError(400, msg); };

function parseCookies(header) {
  const out = {};
  String(header || "").split(";").forEach(p => {
    const i = p.indexOf("=");
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function setSessionCookie(res, token, maxAgeSec) {
  res.setHeader("Set-Cookie",
    `tc_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${SECURE_COOKIE ? "; Secure" : ""}`);
}

/* ---------- app ---------- */
const app = express();
app.disable("x-powered-by");
app.set("trust proxy", "loopback");
app.use(express.json({ limit: "1mb" }));
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
  if (SECURE_COOKIE) res.setHeader("Strict-Transport-Security", "max-age=31536000");
  if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
  next();
});

// Every write comes from our own page: require JSON (blocks simple cross-site form posts).
app.use("/api", (req, res, next) => {
  if (req.method !== "GET" && !req.is("application/json")) return res.status(415).json({ error: "JSON required" });
  next();
});

// Session lookup
app.use("/api", (req, res, next) => {
  const token = parseCookies(req.headers.cookie).tc_session;
  if (token) {
    const row = db.prepare(`SELECT u.id,u.username,u.name,u.role,u.branchId,u.active,s.expiresAt FROM sessions s
      JOIN users u ON u.id=s.userId WHERE s.token=?`).get(sha(token));
    if (row && row.active && row.expiresAt > now()) { req.user = row; req.token = token; }
  }
  next();
});
const auth = (req, res, next) => req.user ? next() : res.status(401).json({ error: "Please sign in." });
// Roles: super = everything, all branches. specialist = tools, calibration and users in their branch (and the counter).
// keeper = issue & receive in their branch. tech = request, confirm, return.
const desk = (req, res, next) => ["super", "specialist", "keeper"].includes(req.user?.role) ? next() : res.status(403).json({ error: "Only the tool room keeper can do this." });
const spec = (req, res, next) => ["super", "specialist"].includes(req.user?.role) ? next() : res.status(403).json({ error: "Only the Parts Specialist or Super User can do this." });
const allBranches = u => u.role === "super";
const inScope = (u, branchId) => allBranches(u) || u.branchId === branchId;
const toolIn = (req, id) => { const t = db.prepare("SELECT * FROM tools WHERE id=?").get(Number(id)); return t && inScope(req.user, t.branchId) ? t : undefined; };
const reqIn = (req, id) => { const r = db.prepare("SELECT * FROM requests WHERE id=?").get(Number(id)); return r && inScope(req.user, r.branchId) ? r : undefined; };
// Branch for a new record: the user's own, or (Super User) the one chosen in the form.
const targetBranch = (req, v) => {
  if (!allBranches(req.user)) return req.user.branchId;
  const b = db.prepare("SELECT id FROM branches WHERE id=?").get(Number(v));
  if (!b) bad("Choose the branch.");
  return b.id;
};
const tech = (req, res, next) => req.user?.role === "tech" ? next() : res.status(403).json({ error: "Only technicians can send requests." });

/* ---------- auth routes ---------- */
const attempts = new Map(); // "ip:<ip>" / "user:<name>" -> {n, until}
const DUMMY_HASH = hashPassword(crypto.randomBytes(8).toString("hex"));
const limited = k => (attempts.get(k)?.until || 0) > now();
const fail = k => {
  const a = attempts.get(k) || { n: 0, until: 0 };
  a.n++; if (a.n >= 8) { a.until = now() + 10 * 60e3; a.n = 0; }
  attempts.set(k, a);
  if (attempts.size > 5000) for (const [key, v] of attempts) if (v.until < now()) attempts.delete(key);
};
app.post("/api/login", (req, res) => {
  const name = str(req.body.username, 60).toLowerCase(), ipK = "ip:" + req.ip, uK = "user:" + name;
  if (limited(ipK) || limited(uK)) return res.status(429).json({ error: "Too many attempts. Wait 10 minutes and try again." });
  const u = db.prepare("SELECT * FROM users WHERE username=?").get(name);
  const ok = checkPassword(String(req.body.password || ""), u ? u.passHash : DUMMY_HASH);
  if (!u || !u.active || !ok) {
    fail(ipK); fail(uK);
    return res.status(401).json({ error: "Wrong username or password." });
  }
  attempts.delete(ipK); attempts.delete(uK);
  const token = crypto.randomBytes(32).toString("hex");
  db.prepare("DELETE FROM sessions WHERE expiresAt < ?").run(now());
  db.prepare("INSERT INTO sessions (token,userId,expiresAt) VALUES (?,?,?)").run(sha(token), u.id, now() + SESSION_DAYS * 864e5);
  setSessionCookie(res, token, SESSION_DAYS * 86400);
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => {
  if (req.token) db.prepare("DELETE FROM sessions WHERE token=?").run(sha(req.token));
  setSessionCookie(res, "", 0);
  res.json({ ok: true });
});
app.post("/api/me/password", auth, (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (!checkPassword(String(req.body.current || ""), u.passHash)) bad("Your current password is wrong.");
  const pw = String(req.body.password || "");
  if (pw.length < 8) bad("Use at least 8 characters.");
  db.prepare("UPDATE users SET passHash=? WHERE id=?").run(hashPassword(pw), u.id);
  db.prepare("DELETE FROM sessions WHERE userId=? AND token<>?").run(u.id, sha(req.token));
  res.json({ ok: true });
});

/* ---------- state ---------- */
app.get("/api/state", auth, (req, res) => {
  // Technicians never receive asset numbers: they must read them off the sticker to confirm receipt.
  const u = req.user, all = allBranches(u), desk = u.role !== "tech";
  const bw = all ? "1=1" : "branchId=" + Number(u.branchId);
  const tools = desk
    ? db.prepare(`SELECT * FROM tools WHERE ${bw} ORDER BY code`).all()
    : db.prepare(`SELECT * FROM tools WHERE ${bw} AND calStatus<>'scrapped' ORDER BY code`).all()
        .map(({ assetNo, serialNo, ...rest }) => rest.holderId === u.id ? rest : { ...rest, holderName: "", wo: "", holderId: rest.holderId ? -1 : null });
  const requests = desk
    ? db.prepare(`SELECT * FROM requests WHERE ${bw} ORDER BY createdAt DESC LIMIT ${all ? 2500 : 1000}`).all()
    : db.prepare(`SELECT * FROM requests WHERE ${bw} AND (techId=? OR status='pending') ORDER BY createdAt DESC LIMIT 800`).all(u.id)
        .map(r => r.techId === u.id ? r : { id: r.id, type: r.type, toolId: r.toolId, status: r.status, techId: null, createdAt: r.createdAt });
  const people = {};
  db.prepare(`SELECT id,name FROM users WHERE ${all ? "1=1" : "role='super' OR branchId=" + Number(u.branchId)}`).all().forEach(p => { people[p.id] = p.name; });
  const technicians = desk
    ? db.prepare(`SELECT id,name,username,branchId FROM users WHERE role='tech' AND active=1 AND ${bw} ORDER BY name`).all() : [];
  const branches = db.prepare("SELECT id,name FROM branches ORDER BY id").all();
  res.json({ me: { id: u.id, name: u.name, username: u.username, role: u.role, branchId: u.branchId },
    today: today(), tools, requests, people, technicians, branches });
});

/* ---------- technician ---------- */
app.post("/api/requests", auth, tech, (req, res) => {
  const type = req.body.type === "in" ? "in" : "out";
  const tool = toolIn(req, req.body.toolId);
  if (!tool) bad("This tool is no longer in the inventory.");
  if (type === "out") {
    const wo = str(req.body.wo, 40), dueAt = str(req.body.dueAt, 10);
    if (!wo) bad("Enter the work order number.");
    if (!isDate(dueAt) || dueAt < today()) bad("Pick a return date from today onwards.");
    if (tool.status !== "available") bad("This tool isn't available right now.");
    if (calExpired(tool)) bad("This tool's calibration has expired.");
    dueCheck(tool, dueAt);
    if (db.prepare("SELECT 1 FROM requests WHERE toolId=? AND type='out' AND status='pending'").get(tool.id)) bad("Someone already requested this tool.");
    if (req.body.agree !== true) bad("Tick the box to accept responsibility for the tool.");
    const ts = now();
    db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,dueAt,note,status,createdAt,pledge,pledgeAt)
      VALUES ('out',?,?,?,?,?,?,?,?,'pending',?,?,?)`).run(tool.id, tool.code, tool.name, req.user.id, req.user.name, wo, dueAt, str(req.body.note), ts,
      requestPledgeText(tool, req.user.name, dueAt, wo), ts);
  } else {
    if (tool.status !== "out" || tool.holderId !== req.user.id) bad("This tool isn't checked out to you.");
    if (db.prepare("SELECT 1 FROM requests WHERE toolId=? AND type='in' AND status='pending'").get(tool.id)) bad("A return is already pending for this tool.");
    db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,note,status,createdAt)
      VALUES ('in',?,?,?,?,?,?,?,'pending',?)`).run(tool.id, tool.code, tool.name, req.user.id, req.user.name, tool.wo, str(req.body.note), now());
  }
  res.json({ ok: true });
});
app.post("/api/requests/:id/cancel", auth, (req, res) => {
  const r = reqIn(req, req.params.id);
  if (!r || r.status !== "pending") bad("This request is no longer pending.");
  if (req.user.role === "tech" && r.techId !== req.user.id) bad("You can only cancel your own requests.");
  db.prepare("UPDATE requests SET status='cancelled', handledAt=?, handledBy=? WHERE id=?").run(now(), req.user.id, r.id);
  res.json({ ok: true });
});

// Technician confirms receipt: asset number from the sticker + responsibility pledge.
const ackTries = new Map(); // "user:tool" -> {n, until}
app.post("/api/tools/:id/ack", auth, tech, (req, res) => {
  const t = toolIn(req, req.params.id);
  if (!t || t.status !== "out" || t.holderId !== req.user.id) bad("This tool isn't checked out to you.");
  if (t.ackAt) bad("You've already confirmed this tool.");
  if (req.body.agree !== true) bad("Tick the box to accept responsibility for the tool.");
  const key = req.user.id + ":" + t.id, a = ackTries.get(key) || { n: 0, until: 0 };
  if (a.until > now()) bad("Too many wrong asset numbers. Ask the tool room keeper to check the sticker with you.");
  const typed = str(req.body.assetNo, 40);
  if (!typed) bad("Type the asset number from the sticker on the tool.");
  if (normAsset(typed) !== normAsset(t.assetNo || t.code)) {
    a.n++; if (a.n >= 5) { a.until = now() + 10 * 60e3; a.n = 0; } ackTries.set(key, a);
    bad("That asset number doesn't match this tool. Check the sticker and try again. If it's a different tool, return it to the keeper.");
  }
  ackTries.delete(key);
  const ts = now();
  db.transaction(() => {
    db.prepare("UPDATE tools SET ackAt=? WHERE id=?").run(ts, t.id);
    if (t.reqId) db.prepare("UPDATE requests SET ackAt=?, ackAsset=?, ackPledge=? WHERE id=?").run(ts, typed, pledgeText(t, req.user.name, t.dueAt, typed), t.reqId);
  })();
  res.json({ ok: true });
});

/* ---------- keeper: requests ---------- */
app.post("/api/requests/:id/issue", auth, desk, (req, res) => {
  db.transaction(() => {
    const r = reqIn(req, req.params.id);
    if (!r || r.status !== "pending" || r.type !== "out") bad("This request is no longer pending.");
    const t = toolIn(req, r.toolId);
    if (!t) bad("This tool is no longer in the inventory.");
    if (t.status !== "available") bad("This tool isn't available right now.");
    if (calExpired(t)) bad("Calibration expired. Recalibrate before issuing.");
    dueCheck(t, r.dueAt || today());
    const ts = now();
    db.prepare("UPDATE tools SET status='out', holderId=?, holderName=?, wo=?, issuedAt=?, dueAt=?, reqId=?, ackAt=NULL WHERE id=?")
      .run(r.techId, r.techName, r.wo, ts, r.dueAt || today(), r.id, t.id);
    db.prepare("UPDATE requests SET status='done', handledAt=?, handledBy=? WHERE id=?").run(ts, req.user.id, r.id);
  })();
  res.json({ ok: true });
});
app.post("/api/requests/:id/decline", auth, desk, (req, res) => {
  const reason = str(req.body.reason);
  if (!reason) bad("Give the technician a reason.");
  const r = reqIn(req, req.params.id);
  if (!r || r.status !== "pending") bad("This request is no longer pending.");
  db.prepare("UPDATE requests SET status='declined', reason=?, handledAt=?, handledBy=? WHERE id=?").run(reason, now(), req.user.id, r.id);
  res.json({ ok: true });
});

/* ---------- keeper: tools ---------- */
app.post("/api/tools/:id/issue", auth, desk, (req, res) => {
  db.transaction(() => {
    const t = toolIn(req, req.params.id);
    if (!t) bad("This tool is no longer in the inventory.");
    if (t.status !== "available") bad("This tool isn't available right now.");
    if (calExpired(t)) bad("Calibration expired. Recalibrate before issuing.");
    const wo = str(req.body.wo, 40), dueAt = str(req.body.dueAt, 10);
    if (!wo) bad("Enter the work order number.");
    if (!isDate(dueAt)) bad("Pick a return date.");
    let techId = null, techName = str(req.body.name, 80);
    if (req.body.techId) {
      const u = db.prepare("SELECT * FROM users WHERE id=? AND role='tech' AND active=1 AND branchId=?").get(Number(req.body.techId), t.branchId);
      if (!u) bad("Pick a technician from this branch.");
      techId = u.id; techName = u.name;
    }
    if (!techName) bad("Choose the technician or type their name.");
    dueCheck(t, dueAt);
    const ts = now();
    const ins = db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,dueAt,note,status,createdAt,handledAt,handledBy)
      VALUES ('out',?,?,?,?,?,?,?,?,'done',?,?,?)`).run(t.id, t.code, t.name, techId, techName, wo, dueAt,
      techId ? "Issued at counter" : "Issued at counter — no account, paper sign-off", ts, ts, req.user.id);
    db.prepare("UPDATE tools SET status='out', holderId=?, holderName=?, wo=?, issuedAt=?, dueAt=?, reqId=?, ackAt=NULL WHERE id=?")
      .run(techId, techName, wo, ts, dueAt, ins.lastInsertRowid, t.id);
  })();
  res.json({ ok: true });
});
app.post("/api/tools/:id/receive", auth, desk, (req, res) => {
  db.transaction(() => {
    const t = toolIn(req, req.params.id);
    if (!t || t.status !== "out") bad("This tool isn't checked out.");
    const cond = req.body.condition === "damaged" ? "damaged" : "good", remark = str(req.body.remark), ts = now();
    const location = str(req.body.location, 40);
    if (!location) bad("Enter where the tool is stored now.");
    db.prepare("UPDATE tools SET status=?, location=?, holderId=NULL, holderName='', wo='', issuedAt=NULL, dueAt='', reqId=NULL, ackAt=NULL WHERE id=?")
      .run(cond === "damaged" ? "service" : "available", location, t.id);
    if (cond === "damaged") {
      db.prepare("UPDATE tools SET calStatus='quarantine', disposition='Damaged on return — inspect' WHERE id=?").run(t.id);
      calEvent(t, "quarantined", { note: `Damaged on return from ${t.holderName || "technician"}${remark ? " · " + remark : ""}` }, req.user.id);
    }
    const open = db.prepare("SELECT id FROM requests WHERE toolId=? AND type='in' AND status='pending'").get(t.id);
    if (open) db.prepare("UPDATE requests SET status='done', condition=?, reason=?, location=?, handledAt=?, handledBy=? WHERE id=?").run(cond, remark, location, ts, req.user.id, open.id);
    else db.prepare(`INSERT INTO requests (type,toolId,toolCode,toolName,techId,techName,wo,status,condition,reason,location,createdAt,handledAt,handledBy)
      VALUES ('in',?,?,?,?,?,?,'done',?,?,?,?,?,?)`).run(t.id, t.code, t.name, t.holderId, t.holderName, t.wo, cond, remark, location, ts, ts, req.user.id);
  })();
  res.json({ ok: true });
});

const EXTRA = ["brand", "model", "serialNo", "rangeText", "unit", "certNo", "lab", "remarks"];
function toolFields(b) {
  const f = { code: str(b.code, 30), name: str(b.name, 80), category: str(b.category, 40), location: str(b.location, 40), calDue: isDate(b.calDue) ? b.calDue : "", assetNo: str(b.assetNo, 40),
    lastCal: isDate(b.lastCal) ? b.lastCal : "", freqMonths: Math.min(120, Math.max(1, parseInt(b.freqMonths, 10) || 12)) };
  for (const k of EXTRA) f[k] = str(b[k], k === "remarks" ? 200 : 80);
  if (!f.code) bad("Enter a tool code.");
  if (!f.name) bad("Enter the tool name.");
  return f;
}
const FCOLS = ["name", "category", "location", "calDue", "assetNo", "lastCal", "freqMonths", ...EXTRA];
app.post("/api/tools", auth, spec, (req, res) => {
  const f = toolFields(req.body), branchId = targetBranch(req, req.body.branchId);
  if (db.prepare("SELECT 1 FROM tools WHERE code=? AND branchId=?").get(f.code, branchId)) bad(`This branch already has a tool with code ${f.code}.`);
  db.prepare(`INSERT INTO tools (branchId,code,${FCOLS.join(",")},createdAt) VALUES (?,?,${FCOLS.map(() => "?").join(",")},?)`)
    .run(branchId, f.code, ...FCOLS.map(k => f[k]), now());
  res.json({ ok: true });
});
app.put("/api/tools/:id", auth, spec, (req, res) => {
  const t = toolIn(req, req.params.id);
  if (!t) bad("This tool is no longer in the inventory.");
  const f = toolFields({ ...req.body, code: t.code });
  // Transfer to another branch (Super User only, tool must be in the crib).
  if (allBranches(req.user) && req.body.branchId && Number(req.body.branchId) !== t.branchId) {
    const nb = targetBranch(req, req.body.branchId);
    if (t.status === "out") bad("Receive this tool before moving it to another branch.");
    if (db.prepare("SELECT 1 FROM tools WHERE code=? AND branchId=?").get(t.code, nb)) bad(`That branch already has a tool with code ${t.code}.`);
    db.prepare("UPDATE tools SET branchId=? WHERE id=?").run(nb, t.id);
    cancelPendingOut(t, req.user.id, "Tool moved to another branch");
  }
  let status = t.status;
  // Calibration holds (lab, quarantine, scrapped) are changed from the Calibration tab, not here.
  if (t.status !== "out" && t.calStatus === "ok" && ["available", "service"].includes(req.body.status)) status = req.body.status;
  db.prepare(`UPDATE tools SET ${FCOLS.map(k => k + "=?").join(", ")}, status=? WHERE id=?`).run(...FCOLS.map(k => f[k]), status, t.id);
  res.json({ ok: true });
});

/* ---------- keeper: calibration ---------- */
let curReq = null; // set per calibration request below
const getTool = id => { const t = toolIn(curReq, id); if (!t) bad("This tool is no longer in the inventory."); return t; };
const notOut = t => { if (t.status === "out") bad("This tool is with a technician. Receive it first."); };
app.get("/api/tools/:id/cal", auth, spec, (req, res) => {
  curReq = req;
  const t = getTool(req.params.id);
  const people = {}; db.prepare("SELECT id,name FROM users").all().forEach(p => people[p.id] = p.name);
  res.json(db.prepare("SELECT * FROM cal_events WHERE toolId=? ORDER BY at DESC, id DESC").all(t.id).map(e => ({ ...e, byName: people[e.byId] || "" })));
});
app.post("/api/tools/:id/cal/record", auth, spec, (req, res) => {
  curReq = req;
  db.transaction(() => {
    const t = getTool(req.params.id); notOut(t);
    if (t.calStatus === "scrapped") bad("This tool is scrapped.");
    const calDate = str(req.body.calDate, 10), pass = req.body.result !== "fail";
    if (!isDate(calDate) || calDate > today()) bad("Enter the calibration date (today or earlier).");
    const certNo = str(req.body.certNo, 60), lab = str(req.body.lab, 80);
    if (!lab) bad("Enter the calibration lab.");
    if (pass && !certNo) bad("Enter the certificate number.");
    const dueDate = isDate(req.body.dueDate) ? req.body.dueDate : addMonths(calDate, t.freqMonths || 12);
    if (pass && dueDate <= today()) bad("The new due date must be in the future. Check the calibration date and frequency.");
    const errPlus = str(req.body.errPlus, 20), errMinus = str(req.body.errMinus, 20), note = str(req.body.note, 200);
    if (pass) {
      db.prepare(`UPDATE tools SET lastCal=?, calDue=?, certNo=?, lab=?, errPlus=?, errMinus=?, calStatus='ok', disposition='', status='available' WHERE id=?`)
        .run(calDate, dueDate, certNo, lab, errPlus, errMinus, t.id);
      calEvent(t, "calibrated", { calDate, dueDate, certNo, lab, errPlus, errMinus, note }, req.user.id);
    } else {
      const disposition = str(req.body.disposition, 60) || "Unfit & to be repaired";
      db.prepare("UPDATE tools SET calStatus='quarantine', disposition=?, status='service' WHERE id=?").run(disposition, t.id);
      cancelPendingOut(t, req.user.id, "Tool failed calibration");
      calEvent(t, "failed", { calDate, certNo, lab, errPlus, errMinus, note: [disposition, note].filter(Boolean).join(" · ") }, req.user.id);
    }
  })();
  res.json({ ok: true });
});
app.post("/api/tools/:id/cal/send", auth, spec, (req, res) => {
  curReq = req;
  db.transaction(() => {
    const t = getTool(req.params.id); notOut(t);
    if (t.calStatus === "scrapped") bad("This tool is scrapped.");
    if (t.calStatus === "at_lab") bad("This tool is already at the lab.");
    const lab = str(req.body.lab, 80) || t.lab, note = str(req.body.note, 200);
    if (!lab) bad("Enter the lab it's going to.");
    db.prepare("UPDATE tools SET calStatus='at_lab', lab=?, status='service' WHERE id=?").run(lab, t.id);
    cancelPendingOut(t, req.user.id, "Tool sent for calibration");
    calEvent(t, "sent", { lab, note }, req.user.id);
  })();
  res.json({ ok: true });
});
app.post("/api/tools/:id/cal/quarantine", auth, spec, (req, res) => {
  curReq = req;
  db.transaction(() => {
    const t = getTool(req.params.id); notOut(t);
    if (t.calStatus === "scrapped") bad("This tool is scrapped.");
    const reason = str(req.body.reason, 200), disposition = str(req.body.disposition, 60) || "Unfit & to be calibrated";
    if (!reason) bad("Give a reason for the quarantine.");
    db.prepare("UPDATE tools SET calStatus='quarantine', disposition=?, status='service' WHERE id=?").run(disposition, t.id);
    cancelPendingOut(t, req.user.id, "Tool quarantined");
    calEvent(t, "quarantined", { note: `${disposition} · ${reason}` }, req.user.id);
  })();
  res.json({ ok: true });
});
app.post("/api/tools/:id/cal/release", auth, spec, (req, res) => {
  curReq = req;
  const t = getTool(req.params.id);
  if (!["quarantine", "at_lab"].includes(t.calStatus)) bad("This tool isn't on hold.");
  if (t.calDue && t.calDue < today()) bad("Calibration has expired. Record a new calibration instead.");
  const lastResult = db.prepare("SELECT type FROM cal_events WHERE toolId=? AND type IN ('calibrated','failed','imported') ORDER BY at DESC, id DESC LIMIT 1").get(t.id);
  if (lastResult?.type === "failed") bad("This tool failed its last calibration. Record a passing calibration to return it to service.");
  db.prepare("UPDATE tools SET calStatus='ok', disposition='', status='available' WHERE id=?").run(t.id);
  calEvent(t, "released", { note: str(req.body.note, 200) }, req.user.id);
  res.json({ ok: true });
});
app.post("/api/tools/:id/cal/scrap", auth, spec, (req, res) => {
  curReq = req;
  db.transaction(() => {
    const t = getTool(req.params.id); notOut(t);
    const reason = str(req.body.reason, 200);
    if (!reason) bad("Give a reason for scrapping.");
    db.prepare("UPDATE tools SET calStatus='scrapped', disposition='Unfit & scrapped', status='service' WHERE id=?").run(t.id);
    cancelPendingOut(t, req.user.id, "Tool scrapped");
    calEvent(t, "scrapped", { note: reason }, req.user.id);
  })();
  res.json({ ok: true });
});

// Paste straight from the calibration register (Excel, tab-separated, quoted cells allowed).
function parseTSV(text) {
  const rows = []; let row = [], f = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; continue; }
    if (c === '"' && f === "") q = true;
    else if (c === "\t") { row.push(f); f = ""; }
    else if (c === "\n") { row.push(f); rows.push(row); row = []; f = ""; }
    else if (c !== "\r") f += c;
  }
  if (f !== "" || row.length) { row.push(f); rows.push(row); }
  return rows.map(r => r.map(c => c.replace(/\s+/g, " ").trim()));
}
function parseRegisterRow(r) {
  if (r.length < 18 || !r[0]) return null;
  const di = [];
  for (let i = 11; i < r.length; i++) if (fromDMY(r[i])) di.push(i);
  if (di.length < 2) return null;
  const [ci, dueI] = di;
  let si = -1;
  for (let i = dueI + 1; i < r.length; i++) if (/^(ok|quarantined)/i.test(r[i])) { si = i; break; }
  if (si < 0) return null;
  const num = (r[0].match(/(\d+)\s*$/) || [])[1];
  const nz = v => (["n/a", "na", "-", "tbc", "0"].includes(String(v).toLowerCase()) ? "" : v);
  const brand = nz(r[1]), model = nz(r[2]), desc = r[5], range = nz(r[6]);
  const statusOk = /^ok/i.test(r[si]);
  const locRaw = r[si + 1] || "", disposition = r[si + 3] || "", remarkRaw = r[si + 4] || "";
  let location = "", remarks = [];
  if (/duplicat|dublicat|certificate|needs|adjust/i.test(locRaw)) { remarks.push(locRaw); if (/ali office/i.test(locRaw)) location = "Ali Office"; }
  else if (/office|cabinet|area|kitting|store|rack|drawer|bay|^[A-Z]\d{2}-\d{2}/i.test(locRaw)) location = locRaw;
  else if (locRaw) remarks.push(`Register: ${locRaw}`);
  if (remarkRaw && remarkRaw !== "-" && !/^new$/i.test(remarkRaw)) remarks.push(remarkRaw);
  let calStatus = "ok";
  const dup = /duplicat|dublicat/i.test(locRaw + " " + remarkRaw);
  if (!statusOk) calStatus = /scrapped$/i.test(disposition) && !/to be/i.test(disposition) ? "scrapped" : /sent for calibration/i.test(locRaw) ? "at_lab" : "quarantine";
  else if (dup) calStatus = "quarantine";
  const bm = [brand, model && !/\d.*(psi|bar|inhg|cmhg|ft-lb)/i.test(model) ? model : ""].filter(Boolean).join(" ");
  const rangeShort = range.length <= 28 ? range : "";
  const name = `${desc} ${rangeShort}`.trim().replace(/\s+/g, " ") + (bm ? ` (${bm})` : "");
  return {
    code: num ? `AST-${num}` : r[0].slice(0, 30), assetNo: r[0].slice(0, 40), brand, model, serialNo: nz(r[3]),
    freqMonths: parseInt(r[4], 10) || 12, description: desc, name: name.slice(0, 80), category: categoryFor(desc),
    rangeText: range, unit: r[7] || "", resolution: r[8] || "", tolPlus: r[9] || "", tolMinus: r[10] || "",
    lastCal: fromDMY(r[ci]), certNo: nz(r[ci + 1]) || "", lab: r[ci + 2] || "", calDue: fromDMY(r[dueI]),
    errPlus: r[dueI + 1] || "", errMinus: r[dueI + 2] || "",
    calStatus, disposition: dup && statusOk ? "Duplicate entry — check register" : (calStatus === "ok" ? "" : disposition || "Quarantined"),
    location, remarks: remarks.join(" · ").slice(0, 200),
  };
}
const RCOLS = ["assetNo", "brand", "model", "serialNo", "freqMonths", "description", "name", "category", "rangeText", "unit", "resolution",
  "tolPlus", "tolMinus", "lastCal", "certNo", "lab", "calDue", "errPlus", "errMinus", "calStatus", "disposition", "remarks"];
app.post("/api/tools/register", auth, spec, (req, res) => {
  const branchId = targetBranch(req, req.body.branchId);
  const rows = parseTSV(String(req.body.rows || ""));
  const out = { added: 0, updated: 0, skipped: 0, inService: 0, hold: 0, scrapped: 0 };
  const find = db.prepare("SELECT * FROM tools WHERE branchId=? AND (code=? OR (assetNo<>'' AND assetNo=?))");
  db.transaction(() => {
    for (const r of rows) {
      const p = parseRegisterRow(r);
      if (!p) { if (r.some(Boolean)) out.skipped++; continue; }
      out[p.calStatus === "ok" ? "inService" : p.calStatus === "scrapped" ? "scrapped" : "hold"]++;
      const ex = find.get(branchId, p.code, p.assetNo);
      let t;
      if (ex) {
        // Never roll back what was done in the app: keep newer calibrations and holds set here.
        if (ex.lastCal && p.lastCal && ex.lastCal > p.lastCal)
          for (const k of ["lastCal", "certNo", "lab", "calDue", "errPlus", "errMinus"]) p[k] = ex[k];
        if (ex.calStatus !== "ok" && p.calStatus === "ok") { p.calStatus = ex.calStatus; p.disposition = ex.disposition; }
        const status = ex.status === "out" ? "out" : p.calStatus === "ok" ? (ex.calStatus === "ok" ? ex.status : "available") : "service";
        db.prepare(`UPDATE tools SET ${RCOLS.map(k => k + "=?").join(", ")}, location=CASE WHEN ?<>'' THEN ? ELSE location END, status=? WHERE id=?`)
          .run(...RCOLS.map(k => p[k]), p.location, p.location, status, ex.id);
        t = ex; out.updated++;
      } else {
        const id = db.prepare(`INSERT INTO tools (branchId,code,${RCOLS.join(",")},location,status,createdAt) VALUES (?,?,${RCOLS.map(() => "?").join(",")},?,?,?)`)
          .run(branchId, p.code, ...RCOLS.map(k => p[k]), p.location, p.calStatus === "ok" ? "available" : "service", now()).lastInsertRowid;
        t = { id, code: p.code }; out.added++;
      }
      if (p.certNo && !db.prepare("SELECT 1 FROM cal_events WHERE toolId=? AND certNo=?").get(t.id, p.certNo))
        calEvent(t, "imported", { calDate: p.lastCal, dueDate: p.calDue, certNo: p.certNo, lab: p.lab, errPlus: p.errPlus, errMinus: p.errMinus, note: "From calibration register" }, req.user.id);
    }
  })();
  res.json({ ok: true, ...out });
});
app.delete("/api/tools/:id", auth, spec, (req, res) => {
  const t = toolIn(req, req.params.id);
  if (!t) return res.json({ ok: true });
  if (t.status === "out") bad("Receive this tool before removing it.");
  if (db.prepare("SELECT 1 FROM requests WHERE toolId=? AND status<>'pending' LIMIT 1").get(t.id) || db.prepare("SELECT 1 FROM cal_events WHERE toolId=? AND type<>'imported' LIMIT 1").get(t.id))
    bad("This tool has history, so it can't be deleted. Use Calibration → Manage → Scrap to retire it and keep its records.");
  db.prepare("UPDATE requests SET status='cancelled', handledAt=?, handledBy=? WHERE toolId=? AND status='pending'").run(now(), req.user.id, t.id);
  db.prepare("DELETE FROM cal_events WHERE toolId=?").run(t.id);
  db.prepare("DELETE FROM tools WHERE id=?").run(t.id);
  res.json({ ok: true });
});
app.post("/api/tools/bulk", auth, spec, (req, res) => {
  const branchId = targetBranch(req, req.body.branchId);
  const lines = String(req.body.rows || "").split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  let added = 0, updated = 0, skipped = 0;
  const find = db.prepare("SELECT id FROM tools WHERE code=? AND branchId=?");
  const ins = db.prepare("INSERT INTO tools (branchId,code,name,category,location,calDue,assetNo,createdAt) VALUES (?,?,?,?,?,?,?,?)");
  const upd = db.prepare("UPDATE tools SET name=?, category=?, location=?, calDue=?, assetNo=? WHERE id=?");
  db.transaction(() => {
    for (const l of lines) {
      const [code, name, category = "", location = "", calDue = "", assetNo = ""] = l.split(/\t|,/).map(s => s.trim());
      if (!code || !name || /^code$/i.test(code)) { skipped++; continue; }
      const f = { code: str(code, 30), name: str(name, 80), category: str(category, 40), location: str(location, 40), calDue: isDate(calDue) ? calDue : "", assetNo: str(assetNo, 40) };
      const ex = find.get(f.code, branchId);
      if (ex) { upd.run(f.name, f.category, f.location, f.calDue, f.assetNo, ex.id); updated++; }
      else { ins.run(branchId, f.code, f.name, f.category, f.location, f.calDue, f.assetNo, now()); added++; }
    }
  })();
  res.json({ ok: true, added, updated, skipped });
});

/* ---------- Parts Specialist: users & branches ---------- */
const ROLES = ["super", "specialist", "keeper", "tech"];
// Super Users have no branch (they see all). Everyone else belongs to one branch.
function userBranch(req, role, v) {
  if (role === "super") { if (!allBranches(req.user)) bad("Only a Super User can create another Super User."); return null; }
  return targetBranch(req, v);
}
app.get("/api/users", auth, spec, (req, res) => {
  const w = allBranches(req.user) ? "" : "WHERE branchId=" + Number(req.user.branchId);
  res.json(db.prepare(`SELECT id,username,name,role,branchId,active,createdAt FROM users ${w} ORDER BY CASE role WHEN 'super' THEN 0 WHEN 'specialist' THEN 1 WHEN 'keeper' THEN 2 ELSE 3 END, name`).all());
});
app.post("/api/users", auth, spec, (req, res) => {
  const username = str(req.body.username, 40), name = str(req.body.name, 80), role = ROLES.includes(req.body.role) ? req.body.role : "tech";
  const branchId = userBranch(req, role, req.body.branchId);
  const pw = String(req.body.password || "");
  if (!/^[A-Za-z0-9._-]{3,40}$/.test(username)) bad("Username: 3–40 letters, numbers, dots, dashes or underscores.");
  if (!name) bad("Enter the person's name.");
  if (pw.length < 8) bad("Password must be at least 8 characters.");
  if (db.prepare("SELECT 1 FROM users WHERE username=?").get(username)) bad("That username is taken.");
  db.prepare("INSERT INTO users (username,name,role,branchId,passHash,createdAt) VALUES (?,?,?,?,?,?)").run(username, name, role, branchId, hashPassword(pw), now());
  res.json({ ok: true });
});
app.put("/api/users/:id", auth, spec, (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE id=?").get(Number(req.params.id));
  if (!u || !(allBranches(req.user) || u.branchId === req.user.branchId)) bad("User not found.");
  if (u.branchId == null && !allBranches(req.user)) bad("User not found.");
  const name = str(req.body.name, 80) || u.name;
  const active = req.body.active === undefined ? u.active : (req.body.active ? 1 : 0);
  if (u.id === req.user.id && !active) bad("You can't deactivate your own account.");
  if (req.body.password && String(req.body.password).length < 8) bad("Password must be at least 8 characters.");
  if (u.active && !active) {
    if (db.prepare("SELECT 1 FROM tools WHERE holderId=? AND status='out'").get(u.id)) bad("This person still holds tools. Receive them before deactivating the account.");
    db.prepare("UPDATE requests SET status='cancelled', handledAt=?, handledBy=? WHERE techId=? AND status='pending'").run(now(), req.user.id, u.id);
  }
  let role = u.role, branchId = u.branchId;
  if (req.body.role !== undefined || req.body.branchId !== undefined) {
    if (u.id === req.user.id) bad("You can't change your own role or branch.");
    role = ROLES.includes(req.body.role) ? req.body.role : u.role;
    branchId = userBranch(req, role, req.body.branchId ?? u.branchId);
    if (u.role === "super" && role !== "super" && db.prepare("SELECT COUNT(*) n FROM users WHERE role='super' AND active=1").get().n <= 1) bad("Keep at least one active Super User.");
    if (role !== u.role || branchId !== u.branchId) {
      if (db.prepare("SELECT 1 FROM tools WHERE holderId=? AND status='out'").get(u.id)) bad("This person still holds tools. Receive them first.");
      db.prepare("UPDATE requests SET status='cancelled', handledAt=?, handledBy=? WHERE techId=? AND status='pending'").run(now(), req.user.id, u.id);
      db.prepare("DELETE FROM sessions WHERE userId=?").run(u.id);
    }
  }
  db.prepare("UPDATE users SET name=?, active=?, role=?, branchId=? WHERE id=?").run(name, active, role, branchId, u.id);
  if (req.body.password) {
    db.prepare("UPDATE users SET passHash=? WHERE id=?").run(hashPassword(String(req.body.password)), u.id);
    db.prepare("DELETE FROM sessions WHERE userId=?").run(u.id);
  }
  if (!active) db.prepare("DELETE FROM sessions WHERE userId=?").run(u.id);
  res.json({ ok: true });
});

app.get("/api/branches", auth, (req, res) => res.json(db.prepare("SELECT id,name FROM branches ORDER BY id").all()));
app.post("/api/branches", auth, spec, (req, res) => {
  if (!allBranches(req.user)) bad("Only a Super User can add branches.");
  const name = str(req.body.name, 60);
  if (!name) bad("Enter the branch name.");
  if (db.prepare("SELECT 1 FROM branches WHERE name=?").get(name)) bad("That branch already exists.");
  db.prepare("INSERT INTO branches (name,createdAt) VALUES (?,?)").run(name, now());
  res.json({ ok: true });
});
app.put("/api/branches/:id", auth, spec, (req, res) => {
  if (!allBranches(req.user)) bad("Only a Super User can rename branches.");
  const name = str(req.body.name, 60);
  if (!name) bad("Enter the branch name.");
  if (db.prepare("SELECT 1 FROM branches WHERE name=? AND id<>?").get(name, Number(req.params.id))) bad("That branch already exists.");
  db.prepare("UPDATE branches SET name=? WHERE id=?").run(name, Number(req.params.id));
  res.json({ ok: true });
});

// Quote a CSV cell; text that Excel would run as a formula (=, +, @, or - not followed by a number) gets a leading apostrophe.
const csvCell = v => { let x = String(v ?? ""); if (/^[=+@\t\r]|^-(?![\d.])/.test(x)) x = "'" + x; return `"${x.replace(/"/g, '""')}"`; };
/* ---------- exports (scoped to the user's branch; ?branch=<id> narrows for Super Users) ---------- */
const branchNames = () => { const m = {}; db.prepare("SELECT id,name FROM branches").all().forEach(b => m[b.id] = b.name); return m; };
const exportWhere = req => {
  if (!allBranches(req.user)) return "branchId=" + Number(req.user.branchId);
  return req.query.branch && /^\d+$/.test(req.query.branch) ? "branchId=" + Number(req.query.branch) : "1=1";
};
app.get("/api/export/log.csv", auth, desk, (req, res) => {
  const people = {}; db.prepare("SELECT id,name FROM users").all().forEach(p => people[p.id] = p.name);
  const bn = branchNames();
  const rows = db.prepare(`SELECT * FROM requests WHERE ${exportWhere(req)} ORDER BY createdAt`).all();
  const iso = ms => ms ? new Date(ms).toISOString().replace("T", " ").slice(0, 16) : "";
  const q = csvCell;
  const head = ["Request ID","Branch","Type","Tool code","Tool name","Technician","Work order","Return by","Note","Status","Condition","Remark / reason","Requested (UTC)","Handled (UTC)","Handled by","Request statement accepted (UTC)","Request statement","Receipt confirmed (UTC)","Asset no. typed by technician","Receipt statement","Stored at (on return)"];
  const body = rows.map(r => [r.id, bn[r.branchId] || "", r.type === "out" ? "Check-out" : "Return", r.toolCode, r.toolName, r.techName || people[r.techId] || "", r.wo, r.dueAt, r.note,
    r.status, r.condition, r.reason, iso(r.createdAt), iso(r.handledAt), people[r.handledBy] || "", iso(r.pledgeAt), r.pledge, iso(r.ackAt), r.ackAsset, r.ackPledge, r.location].map(q).join(","));
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="tool-crib-log-${today()}.csv"`);
  res.send("﻿" + [head.map(q).join(","), ...body].join("\r\n"));
});

app.get("/api/export/register.csv", auth, spec, (req, res) => {
  const bn = branchNames();
  const q = csvCell;
  const st = { ok: "OK", at_lab: "At calibration lab", quarantine: "Quarantined/Discarded", scrapped: "Quarantined/Discarded" };
  const head = ["Branch","Asset No.","Tool Code","Brand","Model","Serial No.","Frequency (months)","Description","Range","Unit","Resolution","Tolerance +","Tolerance -",
    "Calibration Date","Certificate No.","Calibration Lab","Due Date","Error +","Error -","Status","Location / Holder","Disposition","Remarks"];
  const rows = db.prepare(`SELECT * FROM tools WHERE ${exportWhere(req)} ORDER BY branchId, code`).all().map(t => [bn[t.branchId] || "", t.assetNo, t.code, t.brand, t.model, t.serialNo, t.freqMonths,
    t.description || t.name, t.rangeText, t.unit, t.resolution, t.tolPlus, t.tolMinus, toDMY(t.lastCal), t.certNo, t.lab, toDMY(t.calDue),
    t.errPlus, t.errMinus, st[t.calStatus] || "OK", t.status === "out" ? `With ${t.holderName}` : t.location, t.disposition, t.remarks].map(q).join(","));
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="calibration-register-${today()}.csv"`);
  res.send("﻿" + [head.map(q).join(","), ...rows].join("\r\n"));
});

/* ---------- static + errors ---------- */
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err.type === "entity.parse.failed" || err.type === "entity.too.large") return res.status(400).json({ error: "The request couldn't be read. Refresh the page and try again." });
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server. Try again." });
});

app.listen(PORT, () => console.log(`Tool Crib running on http://localhost:${PORT}`));
