// Tool Crib — browser app. Talks to the server through relative "api/..." URLs,
// so the site also works when hosted under a sub-path.
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtT = ms => ms ? new Date(ms).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "—";
const fmtD = d => d ? new Date(d + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";

let me = null, tools = [], reqs = [], people = {}, technicians = [], users = [], serverToday = "", branches = [];
let raw = { tools: [], reqs: [], technicians: [] }, branchSel = "all";
try { branchSel = localStorage.getItem("tc_branch") || "all"; } catch (e) {}
const ROLE_LABEL = { super: "Super User", specialist: "Parts Specialist", keeper: "Tool room keeper", tech: "Technician" };
const isSuper = () => me?.role === "super";
const isSpec = () => me?.role === "super" || me?.role === "specialist";
const bName = id => (branches.find(b => b.id === id) || {}).name || "";
const showAllBranches = () => isSuper() && branchSel === "all";
const branchQS = () => isSuper() && branchSel !== "all" ? `?branch=${encodeURIComponent(branchSel)}` : "";
const branchPill = id => showAllBranches() ? `<span class="pill mute">${esc(bName(id))}</span>` : "";
// Branch picker for forms: Super Users choose; everyone else uses their own branch.
const branchField = (cur, label = "Branch") => isSuper()
  ? `<label>${label}<select name="branchId" required><option value="">Choose a branch</option>${branches.map(b => `<option value="${b.id}"${String(b.id) === String(cur ?? (branchSel !== "all" ? branchSel : "")) ? " selected" : ""}>${esc(b.name)}</option>`).join("")}</select></label>` : "";
function applyBranch() {
  const keep = x => !isSuper() || branchSel === "all" || String(x.branchId) === String(branchSel);
  tools = raw.tools.filter(keep); reqs = raw.reqs.filter(keep); technicians = raw.technicians.filter(keep);
}
let tab = { keeper: "queue", tech: "tools" }, q = "", cat = "All", pollTimer = null, calFilter = "attention";
const today = () => serverToday || new Date().toLocaleDateString("en-CA");
const addDays = (d, n) => { const x = new Date(d + "T00:00:00"); x.setDate(x.getDate() + n); return x.toLocaleDateString("en-CA"); };
const role = () => me?.role === "tech" ? "tech" : "keeper"; // "keeper" = the counter view (keeper, specialist, super)

/* ---------- network ---------- */
async function api(path, body, method) {
  const res = await fetch("api/" + path, {
    method: method || (body ? "POST" : "GET"),
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
    credentials: "same-origin",
  });
  if (res.status === 401 && path !== "login") { showLogin(); throw new Error("Please sign in."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Couldn't reach the server. Check your connection.");
  return data;
}
function toast(msg) { const t = $("#toast"); (($("#dlg").open && $("#dlg")) || document.body).append(t); t.textContent = msg; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => t.hidden = true, 3500); }
async function act(fn, okMsg) {
  try { const r = await fn(); await load(); if (okMsg) toast(typeof okMsg === "function" ? okMsg(r) : okMsg); return true; }
  catch (e) { toast(e.message); return false; }
}
async function load() {
  const s = await api("state");
  me = s.me; people = s.people; serverToday = s.today; branches = s.branches || [];
  raw = { tools: s.tools, reqs: s.requests, technicians: s.technicians };
  if (isSuper() && branchSel !== "all" && !branches.some(b => String(b.id) === String(branchSel))) branchSel = "all";
  applyBranch();
  if (isSpec() && tab.keeper === "users") users = await api("users");
  draw();
}

/* ---------- login ---------- */
function showLogin() {
  clearInterval(pollTimer); pollTimer = null; me = null;
  $("#appView").hidden = true; $("#loginView").hidden = false; $("#lu").focus();
}
$("#loginForm").addEventListener("submit", async ev => {
  ev.preventDefault(); $("#loginErr").textContent = "";
  try {
    await api("login", { username: $("#lu").value, password: $("#lp").value });
    $("#lp").value = ""; await start();
  } catch (e) { $("#loginErr").textContent = e.message; }
});
async function start() {
  await load();
  $("#loginView").hidden = true; $("#appView").hidden = false;
  clearInterval(pollTimer);
  pollTimer = setInterval(() => { if (!document.hidden && !$("#dlg").open) load().catch(() => {}); }, 8000);
}
document.addEventListener("visibilitychange", () => { if (!document.hidden && me) load().catch(() => {}); });

/* ---------- derived ---------- */
const person = (id, fallback) => (id && people[id]) || fallback || "Walk-up";
const calState = t => { if (!t.calDue) return null; const d = today(); if (t.calDue < d) return "expired"; if (t.calDue <= addDays(d, 14)) return "soon"; return "ok"; };
const isOverdue = t => t.status === "out" && t.dueAt && t.dueAt < today();
const pending = () => reqs.filter(r => r.status === "pending");
const myPending = (toolId, type) => reqs.find(r => r.status === "pending" && r.toolId === toolId && r.techId === me.id && (!type || r.type === type));
const anyPendingOut = toolId => reqs.find(r => r.status === "pending" && r.toolId === toolId && r.type === "out");
const toolById = id => tools.find(t => t.id === Number(id));
const unconfirmed = () => tools.filter(t => t.status === "out" && t.holderId === me.id && !t.ackAt);
const ackPill = t => t.ackAt ? `<span class="pill ok">Receipt confirmed ${esc(fmtT(t.ackAt))}</span>`
  : (t.holderId ? `<span class="pill warn">${role() === "keeper" ? "Awaiting technician confirmation" : "Not confirmed yet"}</span>` : `<span class="pill mute">No account · paper sign-off</span>`);
const requestPledgeHtml = (t, due, wo) => `I, <b>${esc(me.name)}</b>, request tool <b>${esc(t.code)}</b> (${esc(t.name)}) for work order <b>${wo ? esc(wo) : "[WO above]"}</b>. When it is handed to me I will check it against its asset sticker. I will return it to the tool room by <b>${esc(due || "[date above]")}</b>${t.calDue ? ` and before its calibration expires on <b>${esc(t.calDue)}</b>` : ""}. While this tool is in my custody I am responsible for it, including its loss, damage or misuse.`;
const pledgeBox = (id, html) => `<div class="notice" id="${id}" style="color:var(--ink);background:var(--surface-2);border:1px solid var(--line)">${html}</div>
    <label style="flex-direction:row;align-items:flex-start;gap:10px;color:var(--ink);font-weight:500"><input type="checkbox" name="agree" required style="width:auto;margin-top:3px">I have read this statement and accept responsibility for this tool.</label>`;
const pledgeHtml = (t, asset) => `I, <b>${esc(me.name)}</b>, confirm that I have received tool <b>${esc(t.code)}</b> (${esc(t.name)}), asset number <b>${asset ? esc(asset) : "[the number you type above]"}</b>, and checked it against its asset sticker. I will return it to the tool room by <b>${esc(t.dueAt || "the agreed date")}</b>${t.calDue ? ` and before its calibration expires on <b>${esc(t.calDue)}</b>` : ""}. While this tool is in my custody I am responsible for it, including its loss, damage or misuse.`;

function statusPills(t) {
  const p = [];
  if (t.status === "out") p.push(isOverdue(t) ? `<span class="pill bad">Overdue</span>` : `<span class="pill info">Checked out</span>`);
  else if (t.calStatus === "at_lab") p.push(`<span class="pill info">At calibration lab</span>`);
  else if (t.calStatus === "quarantine") p.push(`<span class="pill bad">Quarantined</span>`);
  else if (t.calStatus === "scrapped") p.push(`<span class="pill mute">Scrapped</span>`);
  else if (t.status === "service") p.push(`<span class="pill mute">Out of service</span>`);
  else p.push(`<span class="pill ok">Available</span>`);
  const c = (t.calStatus || "ok") === "ok" ? calState(t) : null;
  if (c === "expired") p.push(`<span class="pill bad">Cal expired ${esc(fmtD(t.calDue))}</span>`);
  else if (c === "soon") p.push(`<span class="pill warn">Cal due ${esc(fmtD(t.calDue))}</span>`);
  return `<div class="pills">${p.join("")}</div>`;
}
const active = () => tools.filter(t => t.calStatus !== "scrapped");
const daysLeft = t => t.calDue ? Math.round((new Date(t.calDue + "T00:00:00") - new Date(today() + "T00:00:00")) / 864e5) : null;
const tagHtml = t => `<span class="tag">${esc(t.code || t.toolCode || "—")}</span>`;

/* ---------- header ---------- */
function drawHeader() {
  const v = role();
  $("#meName").textContent = me.name;
  $("#meRole").textContent = ROLE_LABEL[me.role] + (me.branchId ? " · " + bName(me.branchId) : "");
  $("#roleLine").textContent = isSpec() ? "Tools, calibration & users" : v === "keeper" ? "Keeper desk · issue & receive" : "Technician · request & return";
  const sel = $("#branchSel");
  sel.hidden = !isSuper();
  if (isSuper()) sel.innerHTML = `<option value="all">All branches</option>` + branches.map(b => `<option value="${b.id}"${String(b.id) === String(branchSel) ? " selected" : ""}>${esc(b.name)}</option>`).join("");
  const mine = tools.filter(t => t.status === "out" && t.holderId === me.id).length;
  const unconf = unconfirmed().length;
  const tabs = v === "keeper"
    ? [["queue", "Requests", pending().length, true], ["out", "Checked out", tools.filter(t => t.status === "out").length], ["inventory", "Inventory", active().length], ...(isSpec() ? [["cal", "Calibration", calAttention().length, true]] : []), ["log", "Log"], ...(isSpec() ? [["users", "Users"]] : [])]
    : [["tools", "Tools"], ["mine", unconf ? "My tools · confirm" : "My tools", mine, unconf > 0], ["requests", "My requests", reqs.filter(r => r.techId === me.id && r.status === "pending").length]];
  $("#tabs").innerHTML = tabs.map(([k, l, n, hot]) =>
    `<button type="button" data-tab="${k}" aria-current="${tab[v] === k}">${l}${n != null ? `<span class="count${hot && n ? " hot" : ""}">${n}</span>` : ""}</button>`).join("");
}

/* ---------- technician views ---------- */
function vToolsTech() {
  const cats = ["All", ...[...new Set(tools.map(t => t.category).filter(Boolean))].sort()];
  const list = tools.filter(t => (cat === "All" || t.category === cat) &&
    (!q || `${t.code} ${t.name} ${t.category} ${t.location}`.toLowerCase().includes(q.toLowerCase())))
    .sort((a, b) => (a.status === "available" ? 0 : 1) - (b.status === "available" ? 0 : 1) || String(a.code).localeCompare(String(b.code)));
  let body;
  if (!tools.length) body = `<div class="empty"><strong>No tools listed yet</strong>The tool room keeper adds tools here. Once they do, you can request them from this page.</div>`;
  else if (!list.length) body = `<div class="empty"><strong>No tools match “${esc(q)}”</strong>Try the tool code or a shorter name.</div>`;
  else body = `<div class="grid">${list.map(t => {
    const pend = myPending(t.id, "out"), other = anyPendingOut(t.id);
    let a;
    if (t.status === "out" && t.holderId === me.id) a = `<span class="pill info">With you</span>`;
    else if (pend) a = `<button class="btn small" type="button" data-cancel="${pend.id}">Cancel request</button>`;
    else if (t.status !== "available") a = `<button class="btn small" type="button" disabled>Not available</button>`;
    else if (calState(t) === "expired") a = `<button class="btn small" type="button" disabled>Cal expired</button>`;
    else if (other) a = `<button class="btn small" type="button" disabled>Requested by someone</button>`;
    else a = `<button class="btn small primary" type="button" data-request="${t.id}">Request</button>`;
    return `<article class="card">${tagHtml(t)}<div><div class="name">${esc(t.name)}</div>
      <div class="meta">${esc([t.category, t.location].filter(Boolean).join(" · ") || "—")}</div></div>
      ${statusPills(t)}<div class="foot">${pend ? `<span class="pill warn">Waiting for keeper</span>` : "<span></span>"}${a}</div></article>`;
  }).join("")}</div>`;
  const uc = unconfirmed().length;
  return (uc ? `<div class="notice">You have ${uc} tool${uc === 1 ? "" : "s"} to confirm. Open <b>My tools</b> and enter the asset number from the sticker.</div>` : "") +
    `<div class="bar"><div><h2>Tools</h2><p class="sub">Request a tool, then collect it from the tool room counter once it's issued.</p></div>
    <input class="search" id="q" type="search" placeholder="Search code or name" value="${esc(q)}" aria-label="Search tools"></div>
    ${cats.length > 2 ? `<div class="chips">${cats.map(c => `<button type="button" class="chip" data-cat="${esc(c)}" aria-pressed="${c === cat}">${esc(c)}</button>`).join("")}</div>` : ""}
    ${body}`;
}
function vMine() {
  const list = tools.filter(t => t.status === "out" && t.holderId === me.id).sort((a, b) => String(a.dueAt).localeCompare(String(b.dueAt)));
  const body = !list.length
    ? `<div class="empty"><strong>You have no tools checked out</strong>Tools the keeper issues to you show up here, with their return date.</div>`
    : `<div class="list">${list.map(t => { const pend = myPending(t.id, "in");
      return `<div class="row${isOverdue(t) || !t.ackAt ? " overdue" : ""}"><div><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b>${statusPills(t)}${ackPill(t)}</div>
      <div class="kv">WO <b>${esc(t.wo || "—")}</b> · Issued <b>${esc(fmtT(t.issuedAt))}</b> · Return by <b>${esc(fmtD(t.dueAt))}</b>${t.calDue ? ` · Cal valid until <b>${esc(fmtD(t.calDue))}</b>` : ""}</div></div>
      <div class="acts">${!t.ackAt ? `<button class="btn small primary" type="button" data-ack="${t.id}">Confirm receipt</button>` : ""}
      ${pend ? `<span class="pill warn">Return pending</span><button class="btn small" type="button" data-cancel="${pend.id}">Cancel</button>`
        : `<button class="btn small${t.ackAt ? " primary" : ""}" type="button" data-return="${t.id}">Return tool</button>`}</div></div>`; }).join("")}</div>`;
  return `<div><h2>My tools</h2><p class="sub">When you collect a tool, confirm receipt with the asset number from its sticker. To give it back, tap “Return tool” and hand it in at the counter.</p></div>${body}`;
}
function reqRow(r, keeper) {
  const t = toolById(r.toolId) || { code: r.toolCode, name: r.toolName };
  const type = r.type === "out" ? `<span class="pill info">Check-out</span>` : `<span class="pill ok">Return</span>`;
  const st = { pending: `<span class="pill warn">Pending</span>`, done: `<span class="pill ok">${r.type === "out" ? "Issued" : "Received"}${r.condition === "damaged" ? " · damaged" : ""}</span>`,
    declined: `<span class="pill bad">Declined</span>`, cancelled: `<span class="pill mute">Cancelled</span>` }[r.status] || "";
  let a = "";
  if (keeper && r.status === "pending") {
    a = r.type === "out"
      ? `<button class="btn small primary" type="button" data-issue="${r.id}">Issue</button><button class="btn small" type="button" data-decline="${r.id}">Decline</button>`
      : `<button class="btn small primary" type="button" data-receive-req="${r.id}">Receive</button>`;
  } else if (!keeper && r.status === "pending") a = `<button class="btn small" type="button" data-cancel="${r.id}">Cancel</button>`;
  const ack = (r.type === "out" && r.pledgeAt ? `<span class="pill ok">Statement accepted at request</span>` : "") +
    (r.type === "out" && r.status === "done" && r.ackAt ? `<span class="pill ok">Receipt confirmed · asset ${esc(r.ackAsset)}</span>` : "");
  return `<div class="row"><div><div class="who">${keeper ? branchPill(r.branchId) : ""}${type}${tagHtml(t)}<b>${esc(t.name || r.toolName || "")}</b>${keeper ? "" : st}${ack}</div>
    <div class="kv">${keeper ? `By <b>${esc(r.techName || person(r.techId))}</b> · ` : ""}WO <b>${esc(r.wo || "—")}</b>${r.type === "out" ? ` · Return by <b>${esc(fmtD(r.dueAt))}</b>` : ""} · ${esc(fmtT(r.createdAt))}${r.note ? ` · “${esc(r.note)}”` : ""}${r.reason ? ` · ${r.status === "declined" ? "Reason" : "Remark"}: ${esc(r.reason)}` : ""}${r.type === "in" && r.location ? ` · Stored at <b>${esc(r.location)}</b>` : ""}${keeper && r.handledBy ? ` · Handled by <b>${esc(person(r.handledBy, "—"))}</b>` : ""}</div></div>
    <div class="acts">${keeper && r.status !== "pending" ? st : ""}${a}</div></div>`;
}
function vMyRequests() {
  const list = reqs.filter(r => r.techId === me.id);
  return `<div><h2>My requests</h2><p class="sub">Every check-out and return you've asked for, newest first.</p></div>` +
    (list.length ? `<div class="list">${list.map(r => reqRow(r, false)).join("")}</div>` : `<div class="empty"><strong>No requests yet</strong>Pick a tool from the Tools tab to send your first request.</div>`);
}

/* ---------- keeper views ---------- */
function keeperStats() {
  const out = tools.filter(t => t.status === "out");
  const od = out.filter(isOverdue).length, cal = tools.filter(t => (t.calStatus || "ok") === "ok" && calState(t) === "expired").length, p = pending().length;
  return `<div class="stats"><div class="stat${p ? " alert" : ""}"><b>${p}</b><span>Waiting</span></div>
    <div class="stat"><b>${out.length}</b><span>Checked out</span></div>
    <div class="stat${od ? " alert" : ""}"><b>${od}</b><span>Overdue</span></div>
    <div class="stat${cal ? " alert" : ""}"><b>${cal}</b><span>Cal expired</span></div></div>`;
}
function vQueue() {
  const list = pending().slice().sort((a, b) => a.createdAt - b.createdAt);
  return keeperStats() + `<div><h2>Requests</h2><p class="sub">Oldest first. Issue when the technician is at the counter; receive when the tool is in your hand.</p></div>` +
    (list.length ? `<div class="list">${list.map(r => reqRow(r, true)).join("")}</div>` : `<div class="empty"><strong>No requests waiting</strong>New check-out and return requests from technicians appear here automatically.</div>`);
}
function vOut() {
  const list = tools.filter(t => t.status === "out").sort((a, b) => String(a.dueAt).localeCompare(String(b.dueAt)));
  return `<div><h2>Checked out</h2><p class="sub">Who holds what, sorted by return date. Overdue tools are outlined in red.</p></div>` +
    (list.length ? `<div class="list">${list.map(t => `<div class="row${isOverdue(t) ? " overdue" : ""}"><div><div class="who">${branchPill(t.branchId)}${tagHtml(t)}<b>${esc(t.name)}</b>${statusPills(t)}${ackPill(t)}</div>
      <div class="kv">Holder <b>${esc(t.holderName || person(t.holderId))}</b> · WO <b>${esc(t.wo || "—")}</b> · Issued <b>${esc(fmtT(t.issuedAt))}</b> · Return by <b>${esc(fmtD(t.dueAt))}</b></div></div>
      <div class="acts"><button class="btn small primary" type="button" data-receive-tool="${t.id}">Receive</button></div></div>`).join("")}</div>`
      : `<div class="empty"><strong>Every tool is in the crib</strong>Issued tools are listed here until they come back.</div>`);
}
function vInventory() {
  const list = active().filter(t => !q || `${t.code} ${t.assetNo} ${t.name} ${t.category} ${t.location}`.toLowerCase().includes(q.toLowerCase()));
  const head = `<div class="bar"><div><h2>Inventory</h2><p class="sub">${active().length} tools. Calibration-controlled tools with an expired date can't be issued.${tools.some(t => !t.assetNo) ? " Tools without an asset number fall back to the tool code for receipt confirmation." : ""}</p></div>
    <div class="chips"><input class="search" id="q" type="search" placeholder="Search" value="${esc(q)}" aria-label="Search inventory">
    ${isSpec() ? `<button class="btn" type="button" data-bulk>Paste a list</button><button class="btn primary" type="button" data-add>Add tool</button>` : ""}</div></div>`;
  if (!tools.length) return head + (isSpec() ? `<div class="empty"><strong>Start your tool list</strong>Add tools one by one, or paste your existing register (code, name, category, location, cal due date).<br><button class="btn primary" type="button" data-bulk>Paste a list</button></div>`
    : `<div class="empty"><strong>No tools in this branch yet</strong>The Parts Specialist adds tools to the inventory.</div>`);
  const bcol = showAllBranches();
  return head + `<div class="tablewrap"><table><thead><tr>${bcol ? "<th>Branch</th>" : ""}<th>Code</th><th>Asset no.</th><th>Tool</th><th>Category</th><th>Location</th><th>Cal due</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map(t => `<tr>${bcol ? `<td>${esc(bName(t.branchId))}</td>` : ""}<td>${tagHtml(t)}</td><td class="num">${esc(t.assetNo || "—")}</td><td>${esc(t.name)}</td><td>${esc(t.category || "—")}</td><td>${esc(t.location || "—")}</td><td class="num">${esc(t.calDue || "—")}</td>
    <td>${statusPills(t)}</td><td><div class="chips" style="justify-content:flex-end">
    ${t.status === "available" ? `<button class="btn small primary" type="button" data-walkup="${t.id}"${calState(t) === "expired" ? " disabled" : ""}>Issue</button>` : ""}
    ${isSpec() ? `<button class="btn small" type="button" data-edit="${t.id}">Edit</button>` : ""}</div></td></tr>`).join("")}
    </tbody></table></div>`;
}
/* ---------- calibration ---------- */
function calAttention() { return tools.filter(t => t.calStatus === "at_lab" || t.calStatus === "quarantine" || (t.calStatus === "ok" && t.calDue && daysLeft(t) <= 30)); }
const CAL_FILTERS = {
  attention: ["Needs attention", t => calAttention().includes(t)],
  all: ["All active", t => t.calStatus !== "scrapped"],
  expired: ["Expired", t => t.calStatus === "ok" && t.calDue && daysLeft(t) < 0],
  due30: ["Due in 30 days", t => t.calStatus === "ok" && t.calDue && daysLeft(t) >= 0 && daysLeft(t) <= 30],
  due60: ["Due in 31–60 days", t => t.calStatus === "ok" && t.calDue && daysLeft(t) > 30 && daysLeft(t) <= 60],
  lab: ["At lab", t => t.calStatus === "at_lab"],
  quarantine: ["Quarantined", t => t.calStatus === "quarantine"],
  scrapped: ["Scrapped", t => t.calStatus === "scrapped"],
};
const calRank = t => ({ ok: 0, at_lab: 1, quarantine: 2, scrapped: 3 }[t.calStatus || "ok"] ?? 0);
function daysPill(t) {
  if (t.calStatus !== "ok" && t.calStatus) return `<span class="hint">—</span>`;
  if (!t.calDue) return `<span class="pill mute">—</span>`;
  const n = daysLeft(t);
  if (n < 0) return `<span class="pill bad">${-n} day${n === -1 ? "" : "s"} overdue</span>`;
  if (n <= 30) return `<span class="pill warn">${n} day${n === 1 ? "" : "s"}</span>`;
  if (n <= 60) return `<span class="pill info">${n} days</span>`;
  return `<span class="pill ok">${n} days</span>`;
}
function vCal() {
  const count = k => tools.filter(CAL_FILTERS[k][1]).length;
  const stat = (k, label, alert) => `<button type="button" class="stat${alert && count(k) ? " alert" : ""}" data-calf="${k}" style="text-align:left;cursor:pointer;font:inherit;color:inherit"><b>${count(k)}</b><span>${label}</span></button>`;
  const f = CAL_FILTERS[calFilter] ? calFilter : "attention";
  const list = tools.filter(CAL_FILTERS[f][1])
    .filter(t => !q || `${t.code} ${t.assetNo} ${t.name} ${t.serialNo} ${t.lab} ${t.certNo}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => calRank(a) - calRank(b) || String(a.calDue || "9999").localeCompare(String(b.calDue || "9999")) || String(a.code).localeCompare(String(b.code)));
  const head = `<div class="stats" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))">${stat("expired", "Expired", true)}${stat("due30", "Due ≤ 30 days", true)}${stat("due60", "Due 31–60 days")}${stat("lab", "At lab")}${stat("quarantine", "Quarantined")}</div>
    <div class="bar"><div><h2>Calibration</h2><p class="sub">Record certificates, send tools to the lab, and quarantine or scrap tools. Expired and quarantined tools can't be issued.</p></div>
    <div class="chips"><input class="search" id="q" type="search" placeholder="Search code, serial, cert" value="${esc(q)}" aria-label="Search calibration">
    <button class="btn" type="button" data-register>Import register</button><a class="btn" href="api/export/register.csv${branchQS()}">Download register (CSV)</a></div></div>
    <div class="chips">${Object.entries(CAL_FILTERS).map(([k, [l]]) => `<button type="button" class="chip" data-calf="${k}" aria-pressed="${k === f}">${l} <span class="count">${count(k)}</span></button>`).join("")}</div>`;
  if (!list.length) return head + `<div class="empty"><strong>${f === "attention" ? "Nothing needs attention" : "No tools here"}</strong>${f === "attention" ? "No tool is expired, due within 30 days, at the lab or quarantined." : "Try another filter."}</div>`;
  return head + `<div class="tablewrap"><table class="caltable"><thead><tr><th>Code</th><th>Tool</th><th>Serial no.</th><th>Last cal · Cert</th><th>Due</th><th>Left</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map(t => `<tr><td>${tagHtml(t)}<div class="meta num">${esc(t.assetNo || "")}</div>${showAllBranches() ? `<div class="meta">${esc(bName(t.branchId))}</div>` : ""}</td>
      <td>${esc(t.name)}${t.remarks ? `<div class="meta">${esc(t.remarks)}</div>` : ""}${t.disposition ? `<div class="meta">${esc(t.disposition)}</div>` : ""}</td>
      <td class="num">${esc(t.serialNo || "—")}</td>
      <td class="num">${esc(t.lastCal || "—")}<div class="meta">${esc([t.certNo, t.lab].filter(Boolean).join(" · ") || "")}</div></td>
      <td class="num">${esc(t.calDue || "—")}</td><td>${daysPill(t)}</td>
      <td>${statusPills(t)}${t.status === "out" ? `<div class="meta">With ${esc(t.holderName || person(t.holderId))}</div>` : ""}</td>
      <td><div class="chips" style="justify-content:flex-end;flex-wrap:nowrap">
        ${t.status !== "out" && t.calStatus !== "scrapped" ? `<button class="btn small primary" type="button" data-calrec="${t.id}">${t.calStatus === "at_lab" ? "Record result" : "Record cal"}</button>` : ""}
        <button class="btn small" type="button" data-calman="${t.id}">Manage</button></div></td></tr>`).join("")}
    </tbody></table></div>`;
}
function vLog() {
  const list = reqs.filter(r => r.status !== "pending").slice(0, 300);
  return `<div class="bar"><div><h2>Log</h2><p class="sub">Every issue, return, decline and cancellation, newest first. Use it to trace a tool to a work order.</p></div>
    <a class="btn" href="api/export/log.csv${branchQS()}">Download full log (CSV)</a></div>` +
    (list.length ? `<div class="list">${list.map(r => reqRow(r, true)).join("")}</div>` : `<div class="empty"><strong>Nothing logged yet</strong>Completed check-outs and returns are recorded here automatically.</div>`);
}
const ROLE_PILL = { super: "bad", specialist: "warn", keeper: "info", tech: "mute" };
function vUsers() {
  const list = users.filter(u => !isSuper() || branchSel === "all" || u.role === "super" || String(u.branchId) === String(branchSel));
  return `<div class="bar"><div><h2>Users</h2><p class="sub"><b>Super User</b>: everything, all branches. <b>Parts Specialist</b>: tools, calibration and users of their branch. <b>Keeper</b>: issues and receives tools. <b>Technician</b>: requests and returns tools.</p></div>
    <button class="btn primary" type="button" data-adduser>Add user</button></div>
    <div class="tablewrap"><table><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Branch</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map(u => `<tr class="${u.active ? "" : "inactive"}"><td>${esc(u.name)}</td><td class="num">${esc(u.username)}</td>
      <td><span class="pill ${ROLE_PILL[u.role]}">${esc(ROLE_LABEL[u.role])}</span></td>
      <td>${u.branchId ? esc(bName(u.branchId)) : "All branches"}</td>
      <td>${u.active ? `<span class="pill ok">Active</span>` : `<span class="pill mute">Deactivated</span>`}</td>
      <td><div class="chips" style="justify-content:flex-end;flex-wrap:nowrap"><button class="btn small" type="button" data-edituser="${u.id}">Edit</button><button class="btn small" type="button" data-resetpw="${u.id}">Reset password</button>
      ${u.id !== me.id ? `<button class="btn small" type="button" data-toggleuser="${u.id}">${u.active ? "Deactivate" : "Reactivate"}</button>` : ""}</div></td></tr>`).join("")}
    </tbody></table></div>
    ${isSuper() ? `<div class="bar"><div><h2>Branches</h2><p class="sub">Each branch has its own tools, keepers and technicians.</p></div><button class="btn" type="button" data-addbranch>Add branch</button></div>
    <div class="list">${branches.map(b => `<div class="row"><div><b>${esc(b.name)}</b><div class="kv">${raw.tools.filter(t => t.branchId === b.id && t.calStatus !== "scrapped").length} tools · ${users.filter(u => u.branchId === b.id && u.active).length} active users</div></div>
      <div class="acts"><button class="btn small" type="button" data-renamebranch="${b.id}">Rename</button></div></div>`).join("")}</div>` : ""}`;
}

function draw() {
  if (!me) return;
  drawHeader();
  const v = role();
  if (v === "keeper" && !isSpec() && (tab.keeper === "cal" || tab.keeper === "users")) tab.keeper = "queue";
  const view = v === "keeper"
    ? { queue: vQueue, out: vOut, inventory: vInventory, cal: vCal, log: vLog, users: vUsers }[tab.keeper]
    : { tools: vToolsTech, mine: vMine, requests: vMyRequests }[tab.tech];
  const focusQ = document.activeElement && document.activeElement.id === "q";
  const pos = focusQ ? document.activeElement.selectionStart : 0;
  $("#main").innerHTML = view();
  if (focusQ && $("#q")) { $("#q").focus(); try { $("#q").setSelectionRange(pos, pos); } catch (e) {} }
}

/* ---------- dialogs ---------- */
function openDlg(html, onSubmit) {
  const f = $("#dlgForm"); f.innerHTML = html;
  f.onsubmit = async ev => {
    ev.preventDefault();
    const sub = f.querySelector("[type=submit]"); if (sub) sub.disabled = true;
    try { const ok = await onSubmit(new FormData(f), f); if (ok !== false) $("#dlg").close(); }
    finally { if (sub) sub.disabled = false; }
  };
  f.querySelectorAll("[data-close]").forEach(b => b.onclick = () => $("#dlg").close());
  $("#dlg").showModal();
  const first = f.querySelector("input:not([readonly]),select,textarea"); if (first) first.focus();
}
const cancelBtn = `<button class="btn" type="button" data-close>Cancel</button>`;

function dlgRequest(t) {
  openDlg(`<h3>Request tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Work order / job number<input name="wo" required maxlength="40" placeholder="e.g. WO-24811"></label>
    <label>Return by${t.calDue ? ` <span class="hint">No later than the calibration due date, ${esc(fmtD(t.calDue))}</span>` : ""}<input name="due" type="date" required value="${today()}" min="${today()}"${t.calDue ? ` max="${esc(t.calDue)}"` : ""}></label>
    <label>Note for the keeper <span class="hint">Optional</span><input name="note" maxlength="140" placeholder="e.g. Bay 3, QSK60 overhaul"></label>
    ${pledgeBox("reqPledge", requestPledgeHtml(t, today(), ""))}
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Accept and send request</button></div>`,
    fd => act(() => api("requests", { type: "out", toolId: t.id, wo: fd.get("wo"), dueAt: fd.get("due"), note: fd.get("note"), agree: fd.get("agree") === "on" }), "Request sent. Collect the tool at the counter."));
  const f = $("#dlgForm"), upd = () => { $("#reqPledge").innerHTML = requestPledgeHtml(t, f.due.value, f.wo.value.trim()); };
  f.wo.addEventListener("input", upd); f.due.addEventListener("input", upd);
}
function dlgAck(t) {
  openDlg(`<h3>Confirm receipt</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Asset number from the sticker on the tool<input name="assetNo" id="ackAsset" required maxlength="40" autocomplete="off" placeholder="Read it off the sticker"></label>
    ${pledgeBox("pledge", pledgeHtml(t, ""))}
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Confirm and accept</button></div>`,
    fd => act(() => api(`tools/${t.id}/ack`, { assetNo: fd.get("assetNo"), agree: fd.get("agree") === "on" }), "Receipt confirmed. The tool is now in your custody."));
  $("#ackAsset").addEventListener("input", e => { $("#pledge").innerHTML = pledgeHtml(t, e.target.value.trim()); });
}
function dlgReturn(t) {
  openDlg(`<h3>Return tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Anything the keeper should know? <span class="hint">Optional — e.g. damage, missing parts</span><input name="note" maxlength="140"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Send return</button></div>`,
    fd => act(() => api("requests", { type: "in", toolId: t.id, note: fd.get("note") }), "Return sent. Hand the tool in at the counter."));
}
function dlgReceive(t, r) {
  openDlg(`<h3>Receive tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <div class="kv">From <b>${esc(t.holderName || person(t.holderId))}</b> · WO <b>${esc(t.wo || "—")}</b></div>
    ${r && r.note ? `<div class="notice">Technician note: ${esc(r.note)}</div>` : ""}
    <label>Stored at <span class="hint">Where you're putting the tool now: cabinet, drawer, rack</span><input name="location" required maxlength="40" value="${esc(t.location || "")}" list="locList" placeholder="e.g. Cabinet B, drawer 2"></label>
    <datalist id="locList">${[...new Set(raw.tools.filter(x => x.branchId === t.branchId).map(x => x.location).filter(Boolean))].sort().map(l => `<option value="${esc(l)}">`).join("")}</datalist>
    <label>Condition<select name="cond"><option value="good">Good — back in the crib</option><option value="damaged">Damaged — quarantine for inspection</option></select></label>
    <label>Remark <span class="hint">Optional</span><input name="remark" maxlength="140"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Confirm received</button></div>`,
    fd => act(() => api(`tools/${t.id}/receive`, { condition: fd.get("cond"), remark: fd.get("remark"), location: fd.get("location") }),
      fd.get("cond") === "damaged" ? "Received and quarantined. The Parts Specialist will see it under Calibration." : "Received. Tool is back in the crib."));
}
function dlgDecline(r) {
  openDlg(`<h3>Decline request</h3><label>Reason the technician will see<input name="reason" required maxlength="140" placeholder="e.g. Tool reserved for SRC job"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Decline</button></div>`,
    fd => act(() => api(`requests/${r.id}/decline`, { reason: fd.get("reason") }), "Declined."));
}
function dlgWalkup(t) {
  const opts = raw.technicians.filter(u => u.branchId === t.branchId).map(u => `<option value="${u.id}">${esc(u.name)} (${esc(u.username)})</option>`).join("");
  openDlg(`<h3>Issue at the counter</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Technician<select name="techId" id="techSel"><option value="">— Choose from the list —</option>${opts}<option value="other">Someone without an account…</option></select></label>
    <label id="otherWrap" hidden>Name <span class="hint">Without an account they can't confirm receipt in the app. Get a paper sign-off.</span><input name="name" maxlength="80" placeholder="Full name"></label>
    <div class="two"><label>Work order<input name="wo" required maxlength="40"></label>
    <label>Return by<input name="due" type="date" required value="${today()}" min="${today()}"${t.calDue ? ` max="${esc(t.calDue)}"` : ""}></label></div>
    <p class="hint">The technician confirms receipt on their phone with the asset number from the sticker.</p>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Issue tool</button></div>`,
    fd => {
      const sel = fd.get("techId");
      if (!sel) { toast("Choose the technician."); return false; }
      return act(() => api(`tools/${t.id}/issue`, { techId: sel === "other" ? null : Number(sel), name: fd.get("name"), wo: fd.get("wo"), dueAt: fd.get("due") }), "Tool issued.");
    });
  $("#techSel").addEventListener("change", e => { $("#otherWrap").hidden = e.target.value !== "other"; });
}
function dlgTool(t) {
  const n = !t; t = t || {};
  openDlg(`<h3>${n ? "Add tool" : "Edit tool"}</h3>
    <div class="two"><label>Tool code<input name="code" required maxlength="30" value="${esc(t.code || "")}" ${n ? "" : "readonly"} placeholder="e.g. TW-018"></label>
    <label>Category<input name="category" maxlength="40" value="${esc(t.category || "")}" placeholder="e.g. Torque wrench" list="catList"></label></div>
    ${branchField(t.branchId, n ? "Branch" : "Branch <span class=\"hint\">Changing it moves the tool to that branch</span>")}
    <datalist id="catList">${[...new Set(tools.map(x => x.category).filter(Boolean))].map(c => `<option value="${esc(c)}">`).join("")}</datalist>
    <label>Asset number <span class="hint">As printed on the asset sticker. Technicians type it to confirm receipt; they never see it in the app.</span><input name="assetNo" maxlength="40" value="${esc(t.assetNo || "")}" placeholder="e.g. CA-DMM-00418"></label>
    <label>Tool name<input name="name" required maxlength="80" value="${esc(t.name || "")}" placeholder="e.g. Torque wrench 40–200 Nm, 1/2&quot; drive"></label>
    <div class="two"><label>Location<input name="location" maxlength="40" value="${esc(t.location || "")}" placeholder="e.g. Cabinet B, drawer 2"></label>
    <label>Serial no.<input name="serialNo" maxlength="80" value="${esc(t.serialNo || "")}"></label></div>
    <div class="two"><label>Brand<input name="brand" maxlength="80" value="${esc(t.brand || "")}"></label><label>Model<input name="model" maxlength="80" value="${esc(t.model || "")}"></label></div>
    <div class="two"><label>Range<input name="rangeText" maxlength="80" value="${esc(t.rangeText || "")}"></label><label>Unit<input name="unit" maxlength="80" value="${esc(t.unit || "")}"></label></div>
    <div class="two"><label>Last calibration<input name="lastCal" type="date" value="${esc(t.lastCal || "")}"></label>
    <label>Calibration due <span class="hint">Empty if not calibrated</span><input name="calDue" type="date" value="${esc(t.calDue || "")}"></label></div>
    <div class="two"><label>Frequency (months)<input name="freqMonths" type="number" min="1" max="120" value="${esc(t.freqMonths || 12)}"></label>
    <label>Certificate no.<input name="certNo" maxlength="80" value="${esc(t.certNo || "")}"></label></div>
    <label>Calibration lab<input name="lab" maxlength="80" value="${esc(t.lab || "")}" list="labList"></label>
    <datalist id="labList">${labs().map(l => `<option value="${esc(l)}">`).join("")}</datalist>
    <label>Remarks<input name="remarks" maxlength="200" value="${esc(t.remarks || "")}"></label>
    ${!n && t.status !== "out" && (t.calStatus || "ok") === "ok" ? `<label>Status<select name="status"><option value="available"${t.status === "available" ? " selected" : ""}>Available</option><option value="service"${t.status === "service" ? " selected" : ""}>Out of service</option></select></label>` : ""}
    <div class="dacts">${!n && t.status !== "out" ? `<button class="btn danger" type="button" id="del">Remove tool</button><span class="spacer"></span>` : ""}${cancelBtn}<button class="btn primary" type="submit">${n ? "Add tool" : "Save"}</button></div>`,
    fd => {
      const body = Object.fromEntries(fd.entries());
      return n ? act(() => api("tools", body), "Tool added.") : act(() => api(`tools/${t.id}`, body, "PUT"), "Saved.");
    });
  const del = $("#del");
  if (del) del.onclick = async () => {
    if (!del.dataset.armed) { del.dataset.armed = "1"; del.textContent = "Tap again to remove"; return; }
    if (await act(() => api(`tools/${t.id}`, {}, "DELETE"), "Tool removed.")) $("#dlg").close();
  };
}
const labs = () => [...new Set(tools.map(t => t.lab).filter(Boolean))].sort();
const addMonths = (iso, n) => { const [y, m, d] = iso.split("-").map(Number); const t = new Date(Date.UTC(y, m - 1 + n, 1));
  const last = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate(); t.setUTCDate(Math.min(d, last)); return t.toISOString().slice(0, 10); };
function dlgCalRecord(t) {
  const freq = t.freqMonths || 12;
  openDlg(`<h3>Record calibration</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <div class="kv">Serial <b>${esc(t.serialNo || "—")}</b> · Frequency <b>${freq} months</b> · Current due <b>${esc(t.calDue || "—")}</b></div>
    <label>Result<select name="result" id="calRes"><option value="pass">Pass: back in service</option><option value="fail">Fail: quarantine the tool</option></select></label>
    <div class="two"><label>Calibration date<input name="calDate" id="calDate" type="date" required value="${today()}" max="${today()}"></label>
    <label>New due date <span class="hint">Calibration date + ${freq} months</span><input name="dueDate" id="calDue" type="date" value="${addMonths(today(), freq)}"></label></div>
    <div class="two"><label>Certificate no.<input name="certNo" id="calCert" maxlength="60" placeholder="e.g. UIC/DAM/113771"></label>
    <label>Calibration lab<input name="lab" required maxlength="80" value="${esc(t.lab || "")}" list="labList"></label></div>
    <datalist id="labList">${labs().map(l => `<option value="${esc(l)}">`).join("")}</datalist>
    <div class="two"><label>Error + <span class="hint">Optional</span><input name="errPlus" maxlength="20"></label><label>Error − <span class="hint">Optional</span><input name="errMinus" maxlength="20"></label></div>
    <label id="dispWrap" hidden>Disposition<select name="disposition"><option>Unfit & to be repaired</option><option>Unfit & to be calibrated</option><option>Unfit & to be scrapped</option></select></label>
    <label>Note <span class="hint">Optional</span><input name="note" maxlength="200"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Save</button></div>`,
    fd => act(() => api(`tools/${t.id}/cal/record`, Object.fromEntries(fd.entries())),
      fd.get("result") === "fail" ? "Recorded as failed. The tool is quarantined." : "Calibration recorded. The tool is back in service."));
  $("#calDate").addEventListener("change", e => { if (e.target.value) $("#calDue").value = addMonths(e.target.value, freq); });
  $("#calRes").addEventListener("change", e => { const fail = e.target.value === "fail"; $("#dispWrap").hidden = !fail; $("#calCert").required = !fail; });
  $("#calCert").required = true;
}
function dlgCalSend(t) {
  openDlg(`<h3>Send to calibration lab</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Lab<input name="lab" required maxlength="80" value="${esc(t.lab || "")}" list="labList"></label>
    <datalist id="labList">${labs().map(l => `<option value="${esc(l)}">`).join("")}</datalist>
    <label>Note <span class="hint">Optional, e.g. delivery note or PO</span><input name="note" maxlength="200"></label>
    <p class="hint">The tool can't be issued while it's at the lab. Record the result when it comes back.</p>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Mark as sent</button></div>`,
    fd => act(() => api(`tools/${t.id}/cal/send`, Object.fromEntries(fd.entries())), "Marked as at the lab."));
}
function dlgCalQuarantine(t) {
  openDlg(`<h3>Quarantine tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <label>Disposition<select name="disposition"><option>Unfit & to be calibrated</option><option>Unfit & to be repaired</option><option>Unfit & to be scrapped</option></select></label>
    <label>Reason<input name="reason" required maxlength="200" placeholder="e.g. Physical damage, lock problem"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Quarantine</button></div>`,
    fd => act(() => api(`tools/${t.id}/cal/quarantine`, Object.fromEntries(fd.entries())), "Tool quarantined."));
}
function dlgCalScrap(t) {
  openDlg(`<h3>Scrap tool</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b></div>
    <p class="sub">The tool leaves the inventory but stays in the register and history under “Scrapped”.</p>
    <label>Reason<input name="reason" required maxlength="200"></label>
    <div class="dacts">${cancelBtn}<button class="btn danger" type="submit">Scrap tool</button></div>`,
    fd => act(() => api(`tools/${t.id}/cal/scrap`, Object.fromEntries(fd.entries())), "Tool scrapped."));
}
const EVT = { imported: ["Imported from register", "mute"], calibrated: ["Calibrated · pass", "ok"], failed: ["Calibration failed", "bad"], sent: ["Sent to lab", "info"],
  quarantined: ["Quarantined", "bad"], released: ["Released to service", "ok"], scrapped: ["Scrapped", "mute"] };
async function dlgCalManage(t) {
  let hist = [];
  try { hist = await api(`tools/${t.id}/cal`); } catch (e) { return toast(e.message); }
  const canAct = t.status !== "out" && t.calStatus !== "scrapped";
  const fld = (k, v) => `<div><span class="hint">${k}</span><div class="num" style="color:var(--ink)">${esc(v || "—")}</div></div>`;
  openDlg(`<h3>${esc(t.code)} · calibration</h3><div class="who">${tagHtml(t)}<b>${esc(t.name)}</b>${statusPills(t)}</div>
    <div class="two">${fld("Asset no.", t.assetNo)}${fld("Serial no.", t.serialNo)}${fld("Brand · model", [t.brand, t.model].filter(Boolean).join(" "))}${fld("Range · unit", [t.rangeText, t.unit].filter(Boolean).join(" · "))}
    ${fld("Last calibration", t.lastCal)}${fld("Due", t.calDue)}${fld("Certificate", t.certNo)}${fld("Lab", t.lab)}${fld("Frequency", (t.freqMonths || 12) + " months")}${fld("Location", t.status === "out" ? "With " + (t.holderName || person(t.holderId)) : t.location)}</div>
    ${t.disposition ? `<div class="notice">${esc(t.disposition)}</div>` : ""}${t.remarks ? `<p class="hint">${esc(t.remarks)}</p>` : ""}
    ${t.status === "out" ? `<div class="notice">This tool is with a technician. Receive it before sending it to the lab or quarantining it.</div>` : ""}
    <div class="chips">
      ${canAct ? `<button class="btn small primary" type="button" data-calrec="${t.id}">${t.calStatus === "at_lab" ? "Record result" : "Record calibration"}</button>` : ""}
      ${canAct && t.calStatus === "ok" ? `<button class="btn small" type="button" data-calsend="${t.id}">Send to lab</button>` : ""}
      ${canAct && t.calStatus !== "quarantine" ? `<button class="btn small" type="button" data-calq="${t.id}">Quarantine</button>` : ""}
      ${(t.calStatus === "quarantine" || t.calStatus === "at_lab") && t.calDue >= today() ? `<button class="btn small" type="button" data-calrel="${t.id}">Release to service</button>` : ""}
      ${canAct ? `<button class="btn small danger" type="button" data-calscrap="${t.id}">Scrap</button>` : ""}
    </div>
    <div><span class="hint">History</span>
    <div class="list" style="gap:6px;margin-top:6px;max-height:240px;overflow:auto">${hist.length ? hist.map(e => `<div class="kv" style="border-top:1px solid var(--line);padding-top:6px">
      <span class="pill ${EVT[e.type]?.[1] || "mute"}">${esc(EVT[e.type]?.[0] || e.type)}</span> <b>${esc(e.calDate || fmtT(e.at))}</b>
      ${e.certNo ? ` · Cert <b>${esc(e.certNo)}</b>` : ""}${e.lab ? ` · ${esc(e.lab)}` : ""}${e.dueDate ? ` · Due <b>${esc(e.dueDate)}</b>` : ""}${e.errPlus || e.errMinus ? ` · Err ${esc(e.errPlus)} / ${esc(e.errMinus)}` : ""}
      ${e.note ? ` · ${esc(e.note)}` : ""}${e.byName ? ` · by ${esc(e.byName)}` : ""}</div>`).join("") : `<p class="hint">No calibration history yet.</p>`}</div></div>
    <div class="dacts"><button class="btn" type="button" data-close>Close</button></div>`, () => true);
}
function dlgRegister() {
  openDlg(`<h3>Import calibration register</h3>${branchField(undefined, "Import into branch")}
    <label>Copy the rows from your calibration register in Excel (all columns, from Asset No. to Remarks) and paste them here
    <textarea name="rows" required style="min-height:160px" placeholder="CSA-AST 004	Cummins	3164797	3164797	12	Torque Wrench	30 to 250 ft-lb	…"></textarea>
    <span class="hint">Tools are matched by code (CSA-AST 004 → AST-004). Existing tools are updated, new ones added. Quarantined rows stay out of service, scrapped rows are archived. Tools with a technician keep their check-out.</span></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Import</button></div>`,
    fd => act(() => api("tools/register", { rows: fd.get("rows"), branchId: fd.get("branchId") }),
      r => `Added ${r.added}, updated ${r.updated}. In service ${r.inService}, on hold ${r.hold}, scrapped ${r.scrapped}${r.skipped ? `. Skipped ${r.skipped} unreadable rows` : ""}.`));
}
function dlgBulk() {
  openDlg(`<h3>Paste a tool list</h3>${branchField()}
    <label>One tool per line: code, name, category, location, cal due (YYYY-MM-DD), asset number
    <textarea name="rows" required placeholder="TW-018, Torque wrench 40-200 Nm, Torque wrench, Cabinet B, 2027-03-31, CA-00418&#10;DI-004, Dial indicator 0-10 mm, Measuring, Drawer 4, 2027-01-15, CA-00377&#10;PL-031, Bearing puller set, Pullers, Rack 2, , CA-00502"></textarea>
    <span class="hint">Copy rows straight from Excel (tabs work too). Existing codes are updated, not duplicated.</span></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Import</button></div>`,
    fd => act(() => api("tools/bulk", { rows: fd.get("rows"), branchId: fd.get("branchId") }),
      r => `Added ${r.added}, updated ${r.updated}${r.skipped ? `, skipped ${r.skipped}` : ""}.`));
}
const roleOptions = cur => ["tech", "keeper", "specialist", ...(isSuper() ? ["super"] : [])]
  .map(r => `<option value="${r}"${r === cur ? " selected" : ""}>${ROLE_LABEL[r]}</option>`).join("");
function wireRoleBranch() {
  const f = $("#dlgForm"), b = f.querySelector("select[name=branchId]");
  if (!b) return;
  const sync = () => { const sup = f.role.value === "super"; b.closest("label").hidden = sup; b.required = !sup; };
  f.role.addEventListener("change", sync); sync();
}
function dlgEditUser(u) {
  const self = u.id === me.id;
  openDlg(`<h3>Edit user</h3><p class="sub">Username: ${esc(u.username)}</p>
    <label>Full name<input name="name" required maxlength="80" value="${esc(u.name)}"></label>
    ${self ? `<p class="hint">You can't change your own role or branch.</p>` : `<label>Role<select name="role">${roleOptions(u.role)}</select></label>
    ${branchField(u.branchId)}<p class="hint">Changing the role or branch signs them out and cancels their pending requests.</p>`}
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Save</button></div>`,
    fd => act(async () => {
      const body = { name: fd.get("name") };
      if (!self && (fd.get("role") !== u.role || String(fd.get("branchId") || "") !== String(u.branchId ?? ""))) { body.role = fd.get("role"); body.branchId = fd.get("branchId") || null; }
      await api(`users/${u.id}`, body, "PUT"); users = await api("users"); await load();
    }, "Saved."));
  if (!self) wireRoleBranch();
}
function dlgBranch(b) {
  openDlg(`<h3>${b ? "Rename branch" : "Add branch"}</h3>
    <label>Branch name<input name="name" required maxlength="60" value="${esc(b ? b.name : "")}" placeholder="e.g. Jubail"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">${b ? "Save" : "Add branch"}</button></div>`,
    fd => act(() => b ? api(`branches/${b.id}`, { name: fd.get("name") }, "PUT") : api("branches", { name: fd.get("name") }), b ? "Branch renamed." : "Branch added."));
}
function dlgAddUser() {
  openDlg(`<h3>Add user</h3>
    <label>Full name<input name="name" required maxlength="80"></label>
    <div class="two"><label>Username<input name="username" required maxlength="40" pattern="[A-Za-z0-9._\\-]{3,40}" placeholder="e.g. a.rahman"></label>
    <label>Role<select name="role">${roleOptions("tech")}</select></label></div>
    ${branchField()}
    <label>Temporary password <span class="hint">At least 8 characters. Ask them to change it after signing in.</span><input name="password" required minlength="8"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Add user</button></div>`,
    fd => act(async () => { await api("users", Object.fromEntries(fd.entries())); users = await api("users"); }, "User added."));
  wireRoleBranch();
}
function dlgResetPw(u) {
  openDlg(`<h3>Reset password</h3><p class="sub">${esc(u.name)} (${esc(u.username)}) will be signed out everywhere.</p>
    <label>New password<input name="password" required minlength="8"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Reset</button></div>`,
    fd => act(() => api(`users/${u.id}`, { password: fd.get("password") }, "PUT"), "Password reset."));
}
function dlgMyPw() {
  openDlg(`<h3>Change password</h3>
    <label>Current password<input name="current" type="password" required autocomplete="current-password"></label>
    <label>New password<input name="password" type="password" required minlength="8" autocomplete="new-password"></label>
    <div class="dacts">${cancelBtn}<button class="btn primary" type="submit">Change</button></div>`,
    fd => act(() => api("me/password", { current: fd.get("current"), password: fd.get("password") }), "Password changed."));
}

/* ---------- events ---------- */
document.addEventListener("click", async ev => {
  const b = ev.target.closest("button"); if (!b || !me) return;
  const d = b.dataset;
  if (d.tab) { tab[role()] = d.tab; q = ""; if (d.tab === "users") users = await api("users").catch(() => []); draw(); window.scrollTo(0, 0); return; }
  if (d.cat) { cat = d.cat; draw(); return; }
  if (d.calf) { calFilter = d.calf; draw(); return; }
  const inDlg = $("#dlg").open && b.closest("#dlg");
  const calT = id => { if (inDlg) $("#dlg").close(); return toolById(id); };
  if (d.calrec) return dlgCalRecord(calT(d.calrec));
  if (d.calman) return dlgCalManage(toolById(d.calman));
  if (d.calsend) return dlgCalSend(calT(d.calsend));
  if (d.calq) return dlgCalQuarantine(calT(d.calq));
  if (d.calscrap) return dlgCalScrap(calT(d.calscrap));
  if (d.calrel) { if (inDlg) $("#dlg").close(); return act(() => api(`tools/${d.calrel}/cal/release`, {}), "Released to service."); }
  if (d.register !== undefined) return dlgRegister();
  if (d.logout !== undefined) { await api("logout", {}).catch(() => {}); showLogin(); return; }
  if (d.pw !== undefined) return dlgMyPw();
  if (d.request) dlgRequest(toolById(d.request));
  else if (d.return) dlgReturn(toolById(d.return));
  else if (d.ack) dlgAck(toolById(d.ack));
  else if (d.cancel) act(() => api(`requests/${d.cancel}/cancel`, {}), "Request cancelled.");
  else if (d.issue) { b.disabled = true; await act(() => api(`requests/${d.issue}/issue`, {}), "Tool issued."); b.disabled = false; }
  else if (d.decline) dlgDecline(reqs.find(x => x.id === Number(d.decline)));
  else if (d.receiveReq) { const r = reqs.find(x => x.id === Number(d.receiveReq)), t = r && toolById(r.toolId);
    if (!t) return toast("This tool is no longer in the inventory."); dlgReceive(t, r); }
  else if (d.receiveTool) dlgReceive(toolById(d.receiveTool), null);
  else if (d.walkup) dlgWalkup(toolById(d.walkup));
  else if (d.edit) dlgTool(toolById(d.edit));
  else if (d.add !== undefined) dlgTool(null);
  else if (d.bulk !== undefined) dlgBulk();
  else if (d.adduser !== undefined) dlgAddUser();
  else if (d.edituser) dlgEditUser(users.find(u => u.id === Number(d.edituser)));
  else if (d.addbranch !== undefined) dlgBranch(null);
  else if (d.renamebranch) dlgBranch(branches.find(b => b.id === Number(d.renamebranch)));
  else if (d.resetpw) dlgResetPw(users.find(u => u.id === Number(d.resetpw)));
  else if (d.toggleuser) { const u = users.find(x => x.id === Number(d.toggleuser));
    act(async () => { await api(`users/${u.id}`, { active: !u.active }, "PUT"); users = await api("users"); }, u.active ? "User deactivated." : "User reactivated."); }
});
document.addEventListener("change", ev => {
  if (ev.target.id !== "branchSel") return;
  branchSel = ev.target.value; try { localStorage.setItem("tc_branch", branchSel); } catch (e) {}
  applyBranch(); draw();
});
document.addEventListener("input", ev => { if (ev.target.id === "q") { q = ev.target.value; draw(); } });

/* ---------- boot ---------- */
start().catch(() => showLogin());
