#!/usr/bin/env bash
# One-time setup for a fresh Ubuntu 24.04 server (e.g. a DigitalOcean droplet).
# Run as root from the app folder:  bash /opt/tool-crib/setup.sh
# Installs Node.js, starts the app with PM2, adds HTTPS with Caddy,
# turns on the firewall and schedules a daily database backup.
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

if [ "$(id -u)" -ne 0 ]; then echo "Run this as root."; exit 1; fi

echo "=== Tool Crib setup ==="
read -rp "Keeper username [keeper]: " KU; KU=${KU:-keeper}
while true; do
  read -rsp "Keeper password (at least 8 characters, no quotes): " KP; echo
  [ ${#KP} -ge 8 ] && break
  echo "Too short, try again."
done
read -rp "Your own domain, if you have one (press Enter to skip): " DOMAIN

# Small servers: add 1 GB swap so installs don't run out of memory
if ! swapon --show | grep -q .; then
  fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates ufw caddy

if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi

npm ci --omit=dev

IP=$(curl -fsS https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')
HOST=${DOMAIN:-"tools-${IP//./-}.sslip.io"}

if [ ! -f .env ]; then
cat > .env <<EOF
PORT=3000
ADMIN_USERNAME=$KU
ADMIN_PASSWORD="$KP"
ADMIN_NAME=Tool Room Keeper
SECURE_COOKIE=true
DB_PATH=$APP_DIR/data/toolcrib.db
TZ=Asia/Riyadh
EOF
chmod 600 .env
fi

npm install -g pm2 >/dev/null
if pm2 describe tool-crib >/dev/null 2>&1; then pm2 restart tool-crib --update-env
else pm2 start npm --name tool-crib --cwd "$APP_DIR" -- start; fi
pm2 save
pm2 startup systemd -u root --hp /root >/dev/null

cat > /etc/caddy/Caddyfile <<EOF
$HOST {
  reverse_proxy localhost:3000
}
EOF
systemctl restart caddy

ufw allow OpenSSH >/dev/null
ufw allow 80 >/dev/null
ufw allow 443 >/dev/null
ufw --force enable >/dev/null

chmod +x "$APP_DIR/backup.sh"
( crontab -l 2>/dev/null | grep -v 'tool-crib/backup.sh' ; echo "0 2 * * * $APP_DIR/backup.sh >> /var/log/toolcrib-backup.log 2>&1" ) | crontab -

echo
echo "=============================================="
echo "  Done. Open:  https://$HOST"
echo "  Sign in as:  $KU"
echo "  The certificate can take a minute on first visit."
echo "=============================================="
